package vn.edu.eaut.lab3;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class Bai03PhuongTrinhBacNhat extends JFrame {

    private final JTextField txtA = new JTextField();
    private final JTextField txtB = new JTextField();
    private final JLabel lblResult = new JLabel("Nghiệm: —");

    private final Color BLUE = new Color(25, 118, 210);
    private final Color DARK_BLUE = new Color(13, 71, 161);
    private final Color BG = new Color(245, 248, 252);

    public Bai03PhuongTrinhBacNhat() {

        setTitle("Bài 3 - Giải phương trình ax + b = 0");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(620, 500);
        setLocationRelativeTo(null);
        setResizable(false);

        JPanel main = new JPanel(new BorderLayout());
        main.setBackground(BG);

        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(DARK_BLUE);
        header.setBorder(new EmptyBorder(22, 28, 22, 28));

        JLabel title = new JLabel("GIẢI PHƯƠNG TRÌNH BẬC NHẤT");
        title.setFont(new Font("Arial", Font.BOLD, 25));
        title.setForeground(Color.WHITE);

        JLabel subtitle = new JLabel("Dạng phương trình: ax + b = 0");
        subtitle.setFont(new Font("Arial", Font.PLAIN, 13));
        subtitle.setForeground(new Color(220, 235, 255));

        JPanel titleBox = new JPanel();
        titleBox.setOpaque(false);
        titleBox.setLayout(new BoxLayout(titleBox, BoxLayout.Y_AXIS));
        titleBox.add(title);
        titleBox.add(Box.createVerticalStrut(5));
        titleBox.add(subtitle);

        header.add(titleBox, BorderLayout.WEST);

        JLabel icon = new JLabel("∑");
        icon.setFont(new Font("Serif", Font.BOLD, 42));
        icon.setForeground(Color.WHITE);
        header.add(icon, BorderLayout.EAST);

        main.add(header, BorderLayout.NORTH);

        JPanel card = new JPanel(new GridBagLayout());
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(215, 225, 238)),
                new EmptyBorder(25, 30, 25, 30)
        ));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel labelA = createLabel("Hệ số a");
        JLabel labelB = createLabel("Hệ số b");

        styleField(txtA);
        styleField(txtB);

        gbc.gridx = 0;
        gbc.gridy = 0;
        card.add(labelA, gbc);

        gbc.gridx = 1;
        gbc.weightx = 1;
        card.add(txtA, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.weightx = 0;
        card.add(labelB, gbc);

        gbc.gridx = 1;
        gbc.weightx = 1;
        card.add(txtB, gbc);

        JButton btnSolve = createButton(
                "✓  GIẢI PHƯƠNG TRÌNH",
                BLUE
        );

        JButton btnClear = createButton(
                "↻  LÀM MỚI",
                new Color(100, 116, 139)
        );

        JPanel buttons = new JPanel(
                new FlowLayout(
                        FlowLayout.CENTER,
                        10,
                        5
                )
        );

        buttons.setOpaque(false);
        buttons.add(btnSolve);
        buttons.add(btnClear);

        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        card.add(buttons, gbc);

        lblResult.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        17
                )
        );

        lblResult.setForeground(DARK_BLUE);
        lblResult.setHorizontalAlignment(SwingConstants.CENTER);

        gbc.gridy = 3;
        card.add(lblResult, gbc);

        JPanel center = new JPanel(new GridBagLayout());
        center.setBackground(BG);
        center.setBorder(new EmptyBorder(25, 30, 25, 30));
        center.add(card);

        main.add(center, BorderLayout.CENTER);

        add(main);

        btnSolve.addActionListener(
                e -> giaiPhuongTrinh()
        );

        btnClear.addActionListener(
                e -> lamMoi()
        );
    }

    private JLabel createLabel(String text) {

        JLabel label = new JLabel(text);
        label.setFont(new Font("Arial", Font.BOLD, 14));
        label.setForeground(new Color(45, 55, 70));

        return label;
    }

    private void styleField(JTextField field) {

        field.setFont(new Font("Arial", Font.PLAIN, 15));
        field.setPreferredSize(new Dimension(300, 40));

        field.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(
                                new Color(190, 205, 225)
                        ),
                        new EmptyBorder(
                                8,
                                12,
                                8,
                                12
                        )
                )
        );
    }

    private JButton createButton(
            String text,
            Color color
    ) {

        JButton button = new JButton(text);

        button.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        12
                )
        );

        button.setForeground(Color.WHITE);
        button.setBackground(color);

        button.setPreferredSize(
                new Dimension(
                        180,
                        42
                )
        );

        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setCursor(
                new Cursor(
                        Cursor.HAND_CURSOR
                )
        );

        return button;
    }

    private void giaiPhuongTrinh() {

        try {

            double a =
                    Double.parseDouble(
                            txtA.getText().trim()
                    );

            double b =
                    Double.parseDouble(
                            txtB.getText().trim()
                    );

            final double EPS = 1e-9;

            if (
                    Math.abs(a) < EPS
                            && Math.abs(b) < EPS
            ) {

                lblResult.setText(
                        "Nghiệm: Phương trình có vô số nghiệm"
                );

            } else if (
                    Math.abs(a) < EPS
            ) {

                lblResult.setText(
                        "Nghiệm: Phương trình vô nghiệm"
                );

            } else {

                double x = -b / a;

                lblResult.setText(
                        String.format(
                                "Nghiệm: x = %.4f",
                                x
                        )
                );
            }

        } catch (NumberFormatException ex) {

            JOptionPane.showMessageDialog(
                    this,
                    "Vui lòng nhập a và b là số hợp lệ!",
                    "Lỗi dữ liệu",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    private void lamMoi() {

        txtA.setText("");
        txtB.setText("");
        lblResult.setText("Nghiệm: —");

        txtA.requestFocus();
    }

    public static void main(String[] args) {

        SwingUtilities.invokeLater(
                () ->
                        new Bai03PhuongTrinhBacNhat()
                                .setVisible(true)
        );
    }
}