package vn.edu.eaut.lab4;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.math.BigInteger;
import java.util.HashMap;
import java.util.Map;

public class Bai04_FibonacciFrame extends JFrame {

    private JTextField txtN;
    private JButton btnFind;
    private JLabel lblResult;
    private JLabel lblStatus;
    private JProgressBar progressBar;

    private final Color PURPLE_DARK =
            new Color(46, 16, 73);

    private final Color PURPLE =
            new Color(88, 28, 135);

    private final Color TEAL =
            new Color(13, 148, 136);

    private final Color BG =
            new Color(245, 243, 249);

    public Bai04_FibonacciFrame() {

        setTitle("Bài 4 - Fibonacci Memoization");

        setSize(700, 520);

        setLocationRelativeTo(null);

        setDefaultCloseOperation(
                JFrame.DISPOSE_ON_CLOSE
        );

        initUI();
    }

    private void initUI() {

        JPanel main =
                new JPanel(
                        new BorderLayout()
                );

        main.setBackground(BG);

        // HEADER

        JPanel header =
                new JPanel(
                        new BorderLayout()
                );

        header.setBackground(PURPLE_DARK);

        header.setBorder(
                new EmptyBorder(
                        22, 30, 22, 30
                )
        );

        JLabel title =
                new JLabel(
                        "BÀI 4  •  FIBONACCI"
                );

        title.setForeground(Color.WHITE);

        title.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        24
                )
        );

        JLabel tag =
                new JLabel(
                        "MEMOIZATION"
                );

        tag.setForeground(
                new Color(153, 246, 228)
        );

        tag.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        12
                )
        );

        header.add(
                title,
                BorderLayout.WEST
        );

        header.add(
                tag,
                BorderLayout.EAST
        );

        // CONTENT

        JPanel content =
                new JPanel();

        content.setOpaque(false);

        content.setLayout(
                new BoxLayout(
                        content,
                        BoxLayout.Y_AXIS
                )
        );

        content.setBorder(
                new EmptyBorder(
                        35, 45, 30, 45
                )
        );

        JLabel heading =
                new JLabel(
                        "TÌM SỐ FIBONACCI THỨ N"
                );

        heading.setAlignmentX(
                Component.CENTER_ALIGNMENT
        );

        heading.setForeground(PURPLE_DARK);

        heading.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        25
                )
        );

        JLabel description =
                new JLabel(
                        "Sử dụng BigInteger và Memoization"
                );

        description.setAlignmentX(
                Component.CENTER_ALIGNMENT
        );

        description.setForeground(
                new Color(107, 100, 115)
        );

        description.setFont(
                new Font(
                        "Segoe UI",
                        Font.PLAIN,
                        14
                )
        );

        JPanel input =
                new JPanel(
                        new FlowLayout()
                );

        input.setOpaque(false);

        JLabel label =
                new JLabel("Nhập N:");

        label.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        14
                )
        );

        txtN =
                new JTextField(15);

        txtN.setFont(
                new Font(
                        "Segoe UI",
                        Font.PLAIN,
                        15
                )
        );

        btnFind =
                new JButton(
                        "TÌM"
                );

        styleButton(
                btnFind,
                TEAL
        );

        input.add(label);

        input.add(txtN);

        input.add(btnFind);

        progressBar =
                new JProgressBar();

        progressBar.setIndeterminate(false);

        progressBar.setMaximumSize(
                new Dimension(
                        Integer.MAX_VALUE,
                        22
                )
        );

        progressBar.setForeground(TEAL);

        lblStatus =
                new JLabel(
                        "Sẵn sàng"
                );

        lblStatus.setAlignmentX(
                Component.CENTER_ALIGNMENT
        );

        lblStatus.setForeground(
                new Color(107, 100, 115)
        );

        lblResult =
                new JLabel(
                        "Kết quả sẽ hiển thị tại đây"
                );

        lblResult.setAlignmentX(
                Component.CENTER_ALIGNMENT
        );

        lblResult.setForeground(PURPLE);

        lblResult.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        16
                )
        );

        content.add(heading);

        content.add(
                Box.createVerticalStrut(8)
        );

        content.add(description);

        content.add(
                Box.createVerticalStrut(30)
        );

        content.add(input);

        content.add(
                Box.createVerticalStrut(25)
        );

        content.add(progressBar);

        content.add(
                Box.createVerticalStrut(15)
        );

        content.add(lblStatus);

        content.add(
                Box.createVerticalStrut(25)
        );

        content.add(lblResult);

        main.add(
                header,
                BorderLayout.NORTH
        );

        main.add(
                content,
                BorderLayout.CENTER
        );

        add(main);

        btnFind.addActionListener(
                e -> findFibonacci()
        );
    }

    private void styleButton(
            JButton button,
            Color color
    ) {

        button.setForeground(Color.WHITE);

        button.setBackground(color);

        button.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        13
                )
        );

        button.setFocusPainted(false);

        button.setBorderPainted(false);

        button.setCursor(
                new Cursor(
                        Cursor.HAND_CURSOR
                )
        );
    }

    private BigInteger fibonacci(
            int n,
            Map<Integer, BigInteger> memo
    ) {

        if (n <= 1) {

            return BigInteger.valueOf(n);
        }

        if (memo.containsKey(n)) {

            return memo.get(n);
        }

        BigInteger value =
                fibonacci(
                        n - 1,
                        memo
                ).add(
                        fibonacci(
                                n - 2,
                                memo
                        )
                );

        memo.put(n, value);

        return value;
    }

    private void findFibonacci() {

        int n;

        try {

            n = Integer.parseInt(
                    txtN.getText().trim()
            );

            if (n < 0) {

                JOptionPane.showMessageDialog(
                        this,
                        "N phải >= 0",
                        "Thông báo",
                        JOptionPane.WARNING_MESSAGE
                );

                return;
            }

        } catch (NumberFormatException ex) {

            JOptionPane.showMessageDialog(
                    this,
                    "Vui lòng nhập số nguyên hợp lệ",
                    "Lỗi",
                    JOptionPane.ERROR_MESSAGE
            );

            return;
        }

        btnFind.setEnabled(false);

        progressBar.setIndeterminate(true);

        lblResult.setText(
                "Đang tính Fibonacci..."
        );

        lblStatus.setText(
                "Đang xử lý trong nền..."
        );

        SwingWorker<BigInteger, Void> worker =
                new SwingWorker<>() {

                    @Override
                    protected BigInteger doInBackground() {

                        Map<Integer, BigInteger> memo =
                                new HashMap<>();

                        return fibonacci(
                                n,
                                memo
                        );
                    }

                    @Override
                    protected void done() {

                        try {

                            BigInteger result =
                                    get();

                            lblResult.setText(
                                    "Fibonacci("
                                            + n
                                            + ") = "
                                            + result
                            );

                            lblStatus.setText(
                                    "✓ Tính toán hoàn tất"
                            );

                        } catch (Exception ex) {

                            lblResult.setText(
                                    "Có lỗi khi tính Fibonacci"
                            );
                        }

                        progressBar.setIndeterminate(
                                false
                        );

                        progressBar.setValue(100);

                        btnFind.setEnabled(true);
                    }
                };

        worker.execute();
    }
}