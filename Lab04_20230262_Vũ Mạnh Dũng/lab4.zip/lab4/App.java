package vn.edu.eaut.lab4;

import javax.swing.*;
import java.awt.*;

public class App extends JFrame {

    private JButton btn1;
    private JButton btn2;
    private JButton btn3;
    private JButton btn4;
    private JButton btn5;
    private JButton btn6;
    private JButton btn7;
    private JButton btn8;
    private JButton btn9;
    private JButton btn10;

    public App() {

        setTitle("LAB 4 - SWINGWORKER");

        setSize(760, 700);

        setLocationRelativeTo(null);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setResizable(false);

        initUI();
    }

    private void initUI() {

        // ==============================
        // PANEL CHÍNH
        // ==============================

        JPanel mainPanel = new JPanel(
                new BorderLayout(15, 15)
        );

        mainPanel.setBackground(
                UIStyle.BACKGROUND
        );

        mainPanel.setBorder(
                BorderFactory.createEmptyBorder(
                        25,
                        35,
                        25,
                        35
                )
        );


        // ==============================
        // HEADER
        // ==============================

        JLabel title = UIStyle.createTitle(
                "✦ JAVA SWINGWORKER - LAB 4 ✦"
        );

        JLabel subtitle = UIStyle.createSubtitle(
                "Chương 2 • Lập trình giao diện và xử lý tác vụ nền"
        );

        JPanel header = new JPanel(
                new GridLayout(2, 1, 0, 5)
        );

        header.setOpaque(false);

        header.add(title);
        header.add(subtitle);

        mainPanel.add(
                header,
                BorderLayout.NORTH
        );


        // ==============================
        // CARD BÀI TẬP
        // ==============================

        JPanel card = UIStyle.createCard();

        card.setLayout(
                new GridLayout(
                        5,
                        2,
                        15,
                        15
                )
        );


        // ==============================
        // TẠO BUTTON
        // ==============================

        btn1 = UIStyle.createButton(
                "Bài 1 - Countdown"
        );

        btn2 = UIStyle.createButton(
                "Bài 2 - Progress Demo"
        );

        btn3 = UIStyle.createButton(
                "Bài 3 - Tổng số nguyên tố"
        );

        btn4 = UIStyle.createButton(
                "Bài 4 - Fibonacci"
        );

        btn5 = UIStyle.createButton(
                "Bài 5 - Đếm dòng File"
        );

        btn6 = UIStyle.createButton(
                "Bài 6 - Hủy tác vụ"
        );

        btn7 = UIStyle.createButton(
                "Bài 7 - Tìm từ khóa"
        );

        btn8 = UIStyle.createButton(
                "Bài 8 - CSV sinh viên"
        );

        btn9 = UIStyle.createButton(
                "Bài 9 - Tải sản phẩm"
        );

        btn10 = UIStyle.createButton(
                "Bài 10 - Quản lý sản phẩm"
        );


        // ==============================
        // THÊM BUTTON VÀO CARD
        // ==============================

        card.add(btn1);
        card.add(btn2);

        card.add(btn3);
        card.add(btn4);

        card.add(btn5);
        card.add(btn6);

        card.add(btn7);
        card.add(btn8);

        card.add(btn9);
        card.add(btn10);


        mainPanel.add(
                card,
                BorderLayout.CENTER
        );


        // ==============================
        // FOOTER
        // ==============================

        JLabel footer = new JLabel(
                "Đại học Công nghệ Đông Á • Khoa CNTT",
                SwingConstants.CENTER
        );

        footer.setFont(
                new Font(
                        "Segoe UI",
                        Font.PLAIN,
                        12
                )
        );

        footer.setForeground(
                UIStyle.TEXT_LIGHT
        );

        mainPanel.add(
                footer,
                BorderLayout.SOUTH
        );


        // ==============================
        // SỰ KIỆN BÀI 1
        // ==============================

        btn1.addActionListener(e -> {

            new CountdownFrame()
                    .setVisible(true);

        });


        // ==============================
        // SỰ KIỆN BÀI 2
        // ==============================

        btn2.addActionListener(e -> {

            new ProgressDemoFrame()
                    .setVisible(true);

        });


        // ==============================
        // SỰ KIỆN BÀI 3
        // ==============================

        btn3.addActionListener(e -> {

            new Bai03_PrimeSumFrame()
                    .setVisible(true);

        });


        // ==============================
        // SỰ KIỆN BÀI 4
        // ==============================

        btn4.addActionListener(e -> {

            new Bai04_FibonacciFrame()
                    .setVisible(true);

        });


        // ==============================
        // SỰ KIỆN BÀI 5
        // ==============================

        btn5.addActionListener(e -> {

            new Bai05_FileLineCounterFrame()
                    .setVisible(true);

        });


        // ==============================
        // SỰ KIỆN BÀI 6
        // ==============================

        btn6.addActionListener(e -> {

            new Bai06_CancelTaskFrame()
                    .setVisible(true);

        });


        // ==============================
        // SỰ KIỆN BÀI 7
        // ==============================

        btn7.addActionListener(e -> {

            new Bai07_KeywordSearchFrame()
                    .setVisible(true);

        });


        // ==============================
        // SỰ KIỆN BÀI 8
        // ==============================

        btn8.addActionListener(e -> {

            new Bai08_StudentCsvFrame()
                    .setVisible(true);

        });


        // ==============================
        // SỰ KIỆN BÀI 9
        // ==============================

        btn9.addActionListener(e -> {

            new Bai09_ProductLoaderFrame()
                    .setVisible(true);

        });


        // ==============================
        // SỰ KIỆN BÀI 10
        // ==============================

        btn10.addActionListener(e -> {

            new Bai10_ProductManagerFrame()
                    .setVisible(true);

        });


        setContentPane(mainPanel);
    }


    // ==============================
    // MAIN
    // ==============================

    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> {

            try {

                UIManager.setLookAndFeel(
                        UIManager.getSystemLookAndFeelClassName()
                );

            } catch (Exception ignored) {
            }

            new App().setVisible(true);
        });
    }
}