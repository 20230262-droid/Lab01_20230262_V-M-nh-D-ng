LAB 13 - SPRING DATA JPA

Chuc nang:
- Student CRUD voi Spring Data JPA + H2
- Tim kiem sinh vien theo ho ten
- Course CRUD (Bai 8-9)
- Validation va kiem tra ma trung
- H2 Console
- Co san cau hinh MySQL trong application.properties

Chay:
1. Mo bang IntelliJ IDEA.
2. mvn clean package
3. mvn spring-boot:run
4. http://localhost:8080/students
5. http://localhost:8080/courses
6. H2 Console: http://localhost:8080/h2-console
   JDBC URL: jdbc:h2:mem:eautdb
   User: sa
   Password: de trong

Chuyen MySQL:
Mo application.properties, bo comment phan MySQL, tao database eaut_lab13 neu can.
