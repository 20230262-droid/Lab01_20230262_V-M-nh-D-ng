package vn.edu.eaut.lab4;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class Bai06_CancelTaskFrame extends JFrame {

    private JButton btnStart;
    private JButton btnCancel;

    private JProgressBar progressBar;

    private JLabel lblResult;
    private JLabel lblStatus;

    private SwingWorker<Integer, Void> worker;

    private final Color PURPLE_DARK =
            new Color(46, 16, 73);

    private final Color PURPLE =
            new Color(88, 28, 135);

    private final Color TEAL =
            new Color(13, 148, 136);

    private final Color RED =
            new Color(220, 38, 38);

    private final Color BG =
            new Color(245, 243, 249);

    public Bai06_CancelTaskFrame() {

        setTitle("Bài 6 - Hủy tác vụ");

        setSize(650, 480);

        setLocationRelativeTo(null);

        setDefaultCloseOperation(
                JFrame.DISPOSE_ON_CLOSE
        );

        initUI();
    }

    private void initUI() {

        JPanel main =
                new JPanel(
                        new BorderLayout()
                );

        main.setBackground(BG);

        JPanel header =
                new JPanel(
                        new BorderLayout()
                );

        header.setBackground(PURPLE_DARK);

        header.setBorder(
                new EmptyBorder(
                        22, 30, 22, 30
                )
        );

        JLabel title =
                new JLabel(
                        "BÀI 6  •  CANCEL TASK"
                );

        title.setForeground(Color.WHITE);

        title.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        24
                )
        );

        JLabel tag =
                new JLabel(
                        "cancel(true)"
                );

        tag.setForeground(
                new Color(252, 165, 165)
        );

        tag.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        13
                )
        );

        header.add(
                title,
                BorderLayout.WEST
        );

        header.add(
                tag,
                BorderLayout.EAST
        );

        JPanel content =
                new JPanel();

        content.setOpaque(false);

        content.setLayout(
                new BoxLayout(
                        content,
                        BoxLayout.Y_AXIS
                )
        );

        content.setBorder(
                new EmptyBorder(
                        40, 50, 30, 50
                )
        );

        JLabel heading =
                new JLabel(
                        "HỦY TÁC VỤ ĐANG CHẠY"
                );

        heading.setAlignmentX(
                Component.CENTER_ALIGNMENT
        );

        heading.setForeground(PURPLE_DARK);

        heading.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        25
                )
        );

        progressBar =
                new JProgressBar(
                        0,
                        100
                );

        progressBar.setStringPainted(true);

        progressBar.setMaximumSize(
                new Dimension(
                        Integer.MAX_VALUE,
                        24
                )
        );

        progressBar.setForeground(TEAL);

        lblStatus =
                new JLabel(
                        "Sẵn sàng"
                );

        lblStatus.setAlignmentX(
                Component.CENTER_ALIGNMENT
        );

        lblStatus.setFont(
                new Font(
                        "Segoe UI",
                        Font.PLAIN,
                        14
                )
        );

        lblResult =
                new JLabel(
                        "Chưa có tác vụ"
                );

        lblResult.setAlignmentX(
                Component.CENTER_ALIGNMENT
        );

        lblResult.setForeground(PURPLE);

        lblResult.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        18
                )
        );

        JPanel buttons =
                new JPanel(
                        new FlowLayout()
                );

        buttons.setOpaque(false);

        btnStart =
                new JButton(
                        "▶  BẮT ĐẦU"
                );

        btnCancel =
                new JButton(
                        "■  HỦY"
                );

        styleButton(
                btnStart,
                TEAL
        );

        styleButton(
                btnCancel,
                RED
        );

        btnCancel.setEnabled(false);

        buttons.add(btnStart);

        buttons.add(btnCancel);

        content.add(heading);

        content.add(
                Box.createVerticalStrut(35)
        );

        content.add(progressBar);

        content.add(
                Box.createVerticalStrut(15)
        );

        content.add(lblStatus);

        content.add(
                Box.createVerticalStrut(25)
        );

        content.add(lblResult);

        content.add(
                Box.createVerticalStrut(30)
        );

        content.add(buttons);

        main.add(
                header,
                BorderLayout.NORTH
        );

        main.add(
                content,
                BorderLayout.CENTER
        );

        add(main);

        btnStart.addActionListener(
                e -> startTask()
        );

        btnCancel.addActionListener(
                e -> cancelTask()
        );
    }

    private void styleButton(
            JButton button,
            Color color
    ) {

        button.setForeground(Color.WHITE);

        button.setBackground(color);

        button.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        13
                )
        );

        button.setFocusPainted(false);

        button.setBorderPainted(false);
    }

    private void startTask() {

        btnStart.setEnabled(false);

        btnCancel.setEnabled(true);

        progressBar.setValue(0);

        lblResult.setText(
                "Đang xử lý..."
        );

        lblStatus.setText(
                "Tác vụ đang chạy"
        );

        worker =
                new SwingWorker<>() {

                    @Override
                    protected Integer doInBackground()
                            throws Exception {

                        for (
                                int i = 0;
                                i <= 100;
                                i++
                        ) {

                            if (isCancelled()) {
                                return i;
                            }

                            Thread.sleep(100);

                            setProgress(i);
                        }

                        return 100;
                    }

                    @Override
                    protected void done() {

                        if (isCancelled()) {

                            lblResult.setText(
                                    "✕ Đã hủy tác vụ"
                            );

                            lblStatus.setText(
                                    "Tác vụ đã được hủy"
                            );

                        } else {

                            lblResult.setText(
                                    "✓ Tác vụ hoàn thành"
                            );

                            lblStatus.setText(
                                    "Xử lý thành công"
                            );

                            progressBar.setValue(
                                    100
                            );
                        }

                        btnStart.setEnabled(true);

                        btnCancel.setEnabled(false);
                    }
                };

        worker.addPropertyChangeListener(
                evt -> {

                    if (
                            "progress".equals(
                                    evt.getPropertyName()
                            )
                    ) {

                        progressBar.setValue(
                                (int) evt.getNewValue()
                        );
                    }
                }
        );

        worker.execute();
    }

    private void cancelTask() {

        if (
                worker != null
                        && !worker.isDone()
        ) {

            worker.cancel(true);
        }
    }
}