package vn.edu.eaut.lab15.controller;

import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import vn.edu.eaut.lab15.entity.Student;
import vn.edu.eaut.lab15.service.StudentService;

@Controller
@RequestMapping("/students")
public class StudentController {
    private final StudentService service;

    public StudentController(StudentService service) {
        this.service = service;
    }

    @GetMapping
    public String list(@RequestParam(required = false) String keyword, Model model) {
        model.addAttribute("students", service.search(keyword));
        model.addAttribute("keyword", keyword == null ? "" : keyword);
        return "students/list";
    }

    @GetMapping("/new")
    public String create(Model model) {
        model.addAttribute("student", new Student());
        model.addAttribute("pageTitle", "Thêm sinh viên");
        return "students/form";
    }

    @GetMapping("/edit/{id}")
    public String edit(@PathVariable Long id, Model model) {
        model.addAttribute("student", service.findById(id));
        model.addAttribute("pageTitle", "Chỉnh sửa sinh viên");
        return "students/form";
    }

    @PostMapping("/save")
    public String save(@Valid @ModelAttribute Student student, BindingResult result, Model model) {
        if (result.hasErrors()) {
            model.addAttribute("pageTitle", student.getId() == null ? "Thêm sinh viên" : "Chỉnh sửa sinh viên");
            return "students/form";
        }
        service.save(student);
        return "redirect:/students?success=1";
    }

    @GetMapping("/delete/{id}")
    public String delete(@PathVariable Long id) {
        service.delete(id);
        return "redirect:/students?deleted=1";
    }
}
