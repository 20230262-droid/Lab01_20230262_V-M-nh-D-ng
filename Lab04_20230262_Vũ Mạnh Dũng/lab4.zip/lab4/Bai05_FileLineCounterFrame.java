package vn.edu.eaut.lab4;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.io.BufferedReader;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;

public class Bai05_FileLineCounterFrame extends JFrame {

    private File selectedFile;

    private JButton btnChoose;
    private JButton btnCount;

    private JLabel lblFile;
    private JLabel lblResult;
    private JLabel lblStatus;

    private JProgressBar progressBar;

    private final Color PURPLE_DARK =
            new Color(46, 16, 73);

    private final Color PURPLE =
            new Color(88, 28, 135);

    private final Color TEAL =
            new Color(13, 148, 136);

    private final Color BG =
            new Color(245, 243, 249);

    public Bai05_FileLineCounterFrame() {

        setTitle("Bài 5 - Đếm số dòng file");

        setSize(750, 520);

        setLocationRelativeTo(null);

        setDefaultCloseOperation(
                JFrame.DISPOSE_ON_CLOSE
        );

        initUI();
    }

    private void initUI() {

        JPanel main =
                new JPanel(
                        new BorderLayout()
                );

        main.setBackground(BG);

        // HEADER

        JPanel header =
                new JPanel(
                        new BorderLayout()
                );

        header.setBackground(PURPLE_DARK);

        header.setBorder(
                new EmptyBorder(
                        22, 30, 22, 30
                )
        );

        JLabel title =
                new JLabel(
                        "BÀI 5  •  FILE LINE COUNTER"
                );

        title.setForeground(Color.WHITE);

        title.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        23
                )
        );

        JLabel tag =
                new JLabel(
                        "FILE + SWINGWORKER"
                );

        tag.setForeground(
                new Color(153, 246, 228)
        );

        tag.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        12
                )
        );

        header.add(
                title,
                BorderLayout.WEST
        );

        header.add(
                tag,
                BorderLayout.EAST
        );

        // CONTENT

        JPanel content =
                new JPanel();

        content.setOpaque(false);

        content.setLayout(
                new BoxLayout(
                        content,
                        BoxLayout.Y_AXIS
                )
        );

        content.setBorder(
                new EmptyBorder(
                        35, 45, 30, 45
                )
        );

        JLabel heading =
                new JLabel(
                        "ĐỌC FILE VÀ ĐẾM SỐ DÒNG"
                );

        heading.setAlignmentX(
                Component.CENTER_ALIGNMENT
        );

        heading.setForeground(PURPLE_DARK);

        heading.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        25
                )
        );

        JPanel choosePanel =
                new JPanel(
                        new FlowLayout()
                );

        choosePanel.setOpaque(false);

        btnChoose =
                new JButton(
                        "CHỌN FILE"
                );

        btnCount =
                new JButton(
                        "ĐẾM DÒNG"
                );

        styleButton(
                btnChoose,
                PURPLE
        );

        styleButton(
                btnCount,
                TEAL
        );

        choosePanel.add(btnChoose);

        choosePanel.add(btnCount);

        lblFile =
                new JLabel(
                        "Chưa chọn file"
                );

        lblFile.setAlignmentX(
                Component.CENTER_ALIGNMENT
        );

        lblFile.setForeground(
                new Color(107, 100, 115)
        );

        lblFile.setFont(
                new Font(
                        "Segoe UI",
                        Font.PLAIN,
                        13
                )
        );

        lblResult =
                new JLabel(
                        "Số dòng: --"
                );

        lblResult.setAlignmentX(
                Component.CENTER_ALIGNMENT
        );

        lblResult.setForeground(PURPLE);

        lblResult.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        20
                )
        );

        lblStatus =
                new JLabel(
                        "Sẵn sàng"
                );

        lblStatus.setAlignmentX(
                Component.CENTER_ALIGNMENT
        );

        lblStatus.setForeground(
                new Color(107, 100, 115)
        );

        progressBar =
                new JProgressBar(
                        0,
                        100
                );

        progressBar.setStringPainted(true);

        progressBar.setMaximumSize(
                new Dimension(
                        Integer.MAX_VALUE,
                        22
                )
        );

        progressBar.setForeground(TEAL);

        content.add(heading);

        content.add(
                Box.createVerticalStrut(30)
        );

        content.add(choosePanel);

        content.add(
                Box.createVerticalStrut(20)
        );

        content.add(lblFile);

        content.add(
                Box.createVerticalStrut(25)
        );

        content.add(progressBar);

        content.add(
                Box.createVerticalStrut(15)
        );

        content.add(lblStatus);

        content.add(
                Box.createVerticalStrut(25)
        );

        content.add(lblResult);

        main.add(
                header,
                BorderLayout.NORTH
        );

        main.add(
                content,
                BorderLayout.CENTER
        );

        add(main);

        btnChoose.addActionListener(
                e -> chooseFile()
        );

        btnCount.addActionListener(
                e -> countLines()
        );
    }

    private void styleButton(
            JButton button,
            Color color
    ) {

        button.setForeground(Color.WHITE);

        button.setBackground(color);

        button.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        13
                )
        );

        button.setFocusPainted(false);

        button.setBorderPainted(false);

        button.setCursor(
                new Cursor(
                        Cursor.HAND_CURSOR
                )
        );
    }

    private void chooseFile() {

        JFileChooser chooser =
                new JFileChooser();

        int result =
                chooser.showOpenDialog(this);

        if (
                result ==
                        JFileChooser.APPROVE_OPTION
        ) {

            selectedFile =
                    chooser.getSelectedFile();

            lblFile.setText(
                    "File: "
                            + selectedFile
                            .getAbsolutePath()
            );

            lblStatus.setText(
                    "Đã chọn file"
            );
        }
    }

    private void countLines() {

        if (selectedFile == null) {

            JOptionPane.showMessageDialog(
                    this,
                    "Vui lòng chọn file trước",
                    "Thông báo",
                    JOptionPane.WARNING_MESSAGE
            );

            return;
        }

        btnCount.setEnabled(false);

        progressBar.setValue(0);

        lblResult.setText(
                "Đang đọc file..."
        );

        lblStatus.setText(
                "Đang xử lý trong nền..."
        );

        SwingWorker<Long, Void> worker =
                new SwingWorker<>() {

                    @Override
                    protected Long doInBackground()
                            throws Exception {

                        long totalBytes =
                                Files.size(
                                        selectedFile.toPath()
                                );

                        long readBytes = 0;

                        long lines = 0;

                        try (
                                BufferedReader reader =
                                        Files.newBufferedReader(
                                                selectedFile.toPath(),
                                                StandardCharsets.UTF_8
                                        )
                        ) {

                            String line;

                            while (
                                    (line =
                                            reader.readLine())
                                            != null
                            ) {

                                lines++;

                                readBytes +=
                                        line.getBytes(
                                                StandardCharsets.UTF_8
                                        ).length + 1;

                                int progress =
                                        totalBytes == 0
                                                ? 100
                                                : (int)
                                                Math.min(
                                                        100,
                                                        readBytes
                                                                * 100
                                                                / totalBytes
                                                );

                                setProgress(
                                        progress
                                );
                            }
                        }

                        return lines;
                    }

                    @Override
                    protected void done() {

                        try {

                            long lineCount = get();

                            lblResult.setText(
                                    "Số dòng: "
                                            + lineCount
                            );

                            lblStatus.setText(
                                    "✓ Đọc file hoàn tất"
                            );

                        } catch (Exception ex) {

                            lblResult.setText(
                                    "Lỗi khi đọc file"
                            );
                        }

                        progressBar.setValue(100);

                        btnCount.setEnabled(true);
                    }
                };

        worker.addPropertyChangeListener(
                evt -> {

                    if (
                            "progress".equals(
                                    evt.getPropertyName()
                            )
                    ) {

                        progressBar.setValue(
                                (int) evt.getNewValue()
                        );
                    }
                }
        );

        worker.execute();
    }
}