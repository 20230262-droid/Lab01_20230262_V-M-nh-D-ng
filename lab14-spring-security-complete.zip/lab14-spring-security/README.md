# LAB 14 - Bảo mật ứng dụng với Spring Security

## 1. Công nghệ
- JDK 17+
- Maven 3.x
- Spring Boot 3.5.x
- Spring Security 6
- Thymeleaf + Thymeleaf Security
- Spring Data JPA
- H2 Database

## 2. Tài khoản kiểm thử
| Username | Password | Role |
|---|---|---|
| admin | 123456 | ADMIN |
| user | 123456 | USER |

## 3. Chạy project
```bash
mvn clean package
mvn spring-boot:run
```
Mở: http://localhost:8080

## 4. Minh chứng nên chụp
1. Trang login.
2. Đăng nhập ADMIN: thấy nút Thêm/Sửa/Xóa và menu Khóa học.
3. Đăng nhập USER: chỉ thấy danh sách, không thấy nút quản trị.
4. USER truy cập /courses -> 403.
5. ADMIN thêm sinh viên.
6. ADMIN sửa/xóa sinh viên.
7. Đăng xuất -> quay về trang chủ.

## 5. Mapping quyền
- /, /about, /login, /css/**: public
- /students/**: ADMIN hoặc USER
- /students/create, /students/edit/**, /students/delete/**: ADMIN
- /courses/**: ADMIN
- URL còn lại: authenticated

## 6. Lưu ý
User được tạo trong bộ nhớ theo đúng yêu cầu bài lab. Dữ liệu sinh viên được lưu bằng H2/JPA để phần CRUD có tính thực tế và có thể mở rộng sang MySQL.
