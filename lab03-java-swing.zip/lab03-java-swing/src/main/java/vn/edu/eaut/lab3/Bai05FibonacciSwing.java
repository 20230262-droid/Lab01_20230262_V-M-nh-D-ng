package vn.edu.eaut.lab3;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class Bai05FibonacciSwing extends JFrame {

    private final JTextField txtN = new JTextField();

    private final JTextArea txtArea =
            new JTextArea();

    private final Color BLUE =
            new Color(25, 118, 210);

    private final Color DARK_BLUE =
            new Color(13, 71, 161);

    private final Color BG =
            new Color(245, 248, 252);

    public Bai05FibonacciSwing() {

        setTitle(
                "Bài 5 - Hiển thị dãy Fibonacci"
        );

        setDefaultCloseOperation(
                JFrame.EXIT_ON_CLOSE
        );

        setSize(
                720,
                520
        );

        setLocationRelativeTo(null);

        setResizable(false);


        JPanel main =
                new JPanel(
                        new BorderLayout()
                );

        main.setBackground(BG);


        // HEADER

        JPanel header =
                new JPanel(
                        new BorderLayout()
                );

        header.setBackground(
                DARK_BLUE
        );

        header.setBorder(
                new EmptyBorder(
                        22,
                        28,
                        22,
                        28
                )
        );


        JLabel title =
                new JLabel(
                        "DÃY FIBONACCI"
                );

        title.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        27
                )
        );

        title.setForeground(
                Color.WHITE
        );


        JLabel subtitle =
                new JLabel(
                        "Hiển thị n số Fibonacci đầu tiên"
                );

        subtitle.setFont(
                new Font(
                        "Arial",
                        Font.PLAIN,
                        13
                )
        );

        subtitle.setForeground(
                new Color(
                        220,
                        235,
                        255
                )
        );


        JPanel titleBox =
                new JPanel();

        titleBox.setOpaque(false);

        titleBox.setLayout(
                new BoxLayout(
                        titleBox,
                        BoxLayout.Y_AXIS
                )
        );

        titleBox.add(title);

        titleBox.add(
                Box.createVerticalStrut(5)
        );

        titleBox.add(subtitle);


        header.add(
                titleBox,
                BorderLayout.WEST
        );


        JLabel icon =
                new JLabel("∞");

        icon.setFont(
                new Font(
                        "Serif",
                        Font.BOLD,
                        45
                )
        );

        icon.setForeground(
                Color.WHITE
        );

        header.add(
                icon,
                BorderLayout.EAST
        );


        main.add(
                header,
                BorderLayout.NORTH
        );


        // INPUT PANEL

        JPanel inputPanel =
                new JPanel(
                        new FlowLayout(
                                FlowLayout.LEFT,
                                12,
                                12
                        )
                );

        inputPanel.setBackground(
                Color.WHITE
        );

        inputPanel.setBorder(
                BorderFactory.createLineBorder(
                        new Color(
                                215,
                                225,
                                238
                        )
                )
        );


        JLabel label =
                new JLabel(
                        "Nhập n:"
                );

        label.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        14
                )
        );


        txtN.setFont(
                new Font(
                        "Arial",
                        Font.PLAIN,
                        15
                )
        );

        txtN.setPreferredSize(
                new Dimension(
                        150,
                        40
                )
        );

        txtN.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(
                                new Color(
                                        190,
                                        205,
                                        225
                                )
                        ),
                        new EmptyBorder(
                                8,
                                10,
                                8,
                                10
                        )
                )
        );


        JButton btnShow =
                new JButton(
                        "▶  HIỂN THỊ"
                );

        btnShow.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        12
                )
        );

        btnShow.setForeground(
                Color.WHITE
        );

        btnShow.setBackground(
                BLUE
        );

        btnShow.setPreferredSize(
                new Dimension(
                        140,
                        40
                )
        );

        btnShow.setFocusPainted(false);

        btnShow.setBorderPainted(false);

        btnShow.setCursor(
                new Cursor(
                        Cursor.HAND_CURSOR
                )
        );


        inputPanel.add(label);
        inputPanel.add(txtN);
        inputPanel.add(btnShow);


        JPanel inputWrapper =
                new JPanel(
                        new BorderLayout()
                );

        inputWrapper.setBackground(
                BG
        );

        inputWrapper.setBorder(
                new EmptyBorder(
                        18,
                        20,
                        0,
                        20
                )
        );

        inputWrapper.add(
                inputPanel,
                BorderLayout.CENTER
        );


        main.add(
                inputWrapper,
                BorderLayout.NORTH
        );


        // TEXT AREA

        txtArea.setEditable(false);

        txtArea.setFont(
                new Font(
                        "Consolas",
                        Font.PLAIN,
                        15
                )
        );

        txtArea.setLineWrap(true);

        txtArea.setWrapStyleWord(true);

        txtArea.setBackground(
                new Color(
                        250,
                        252,
                        255
                )
        );

        txtArea.setBorder(
                new EmptyBorder(
                        15,
                        15,
                        15,
                        15
                )
        );


        JScrollPane scrollPane =
                new JScrollPane(
                        txtArea
                );

        scrollPane.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(
                                new Color(
                                        215,
                                        225,
                                        238
                                )
                        ),
                        new EmptyBorder(
                                5,
                                5,
                                5,
                                5
                        )
                )
        );


        JPanel resultPanel =
                new JPanel(
                        new BorderLayout()
                );

        resultPanel.setBackground(
                Color.WHITE
        );

        resultPanel.setBorder(
                new EmptyBorder(
                        15,
                        20,
                        20,
                        20
                )
        );


        JLabel resultTitle =
                new JLabel(
                        "KẾT QUẢ"
                );

        resultTitle.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        16
                )
        );

        resultTitle.setForeground(
                DARK_BLUE
        );

        resultPanel.add(
                resultTitle,
                BorderLayout.NORTH
        );

        resultPanel.add(
                scrollPane,
                BorderLayout.CENTER
        );


        main.add(
                resultPanel,
                BorderLayout.CENTER
        );


        add(main);


        btnShow.addActionListener(
                e -> hienThiFibonacci()
        );


        txtN.requestFocus();
    }


    private void hienThiFibonacci() {

        try {

            int n =
                    Integer.parseInt(
                            txtN.getText().trim()
                    );


            if (
                    n <= 0
                            || n > 92
            ) {

                JOptionPane.showMessageDialog(
                        this,
                        "n phải từ 1 đến 92 để tránh tràn số long!",
                        "Giá trị không hợp lệ",
                        JOptionPane.WARNING_MESSAGE
                );

                return;
            }


            txtArea.setText(
                    taoDayFibonacci(n)
            );


        } catch (
                NumberFormatException ex
        ) {

            JOptionPane.showMessageDialog(
                    this,
                    "n phải là số nguyên dương!",
                    "Lỗi dữ liệu",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }


    private String taoDayFibonacci(
            int n
    ) {

        StringBuilder sb =
                new StringBuilder();


        long a = 0;
        long b = 1;


        for (
                int i = 1;
                i <= n;
                i++
        ) {

            if (i > 1) {

                sb.append("    ");
            }


            sb.append(a);


            long next =
                    a + b;

            a = b;

            b = next;
        }


        return sb.toString();
    }


    public static void main(
            String[] args
    ) {

        SwingUtilities.invokeLater(
                () ->
                        new Bai05FibonacciSwing()
                                .setVisible(true)
        );
    }
}