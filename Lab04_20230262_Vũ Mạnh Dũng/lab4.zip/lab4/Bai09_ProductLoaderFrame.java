package vn.edu.eaut.lab4;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class Bai09_ProductLoaderFrame extends JFrame {

    private JButton btnLoad;

    private JTable table;

    private JLabel lblStatus;

    private JProgressBar progressBar;

    private final Color PURPLE_DARK =
            new Color(46, 16, 73);

    private final Color PURPLE =
            new Color(88, 28, 135);

    private final Color TEAL =
            new Color(13, 148, 136);

    private final Color BG =
            new Color(245, 243, 249);

    public Bai09_ProductLoaderFrame() {

        setTitle(
                "Bài 9 - Tải sản phẩm"
        );

        setSize(750, 550);

        setLocationRelativeTo(null);

        setDefaultCloseOperation(
                JFrame.DISPOSE_ON_CLOSE
        );

        initUI();
    }

    private void initUI() {

        JPanel main =
                new JPanel(
                        new BorderLayout()
                );

        main.setBackground(BG);

        JPanel header =
                new JPanel(
                        new BorderLayout()
                );

        header.setBackground(PURPLE_DARK);

        header.setBorder(
                new EmptyBorder(
                        22, 30, 22, 30
                )
        );

        JLabel title =
                new JLabel(
                        "BÀI 9  •  PRODUCT LOADER"
                );

        title.setForeground(Color.WHITE);

        title.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        23
                )
        );

        JLabel tag =
                new JLabel(
                        "JTABLE + SWINGWORKER"
                );

        tag.setForeground(
                new Color(153, 246, 228)
        );

        tag.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        12
                )
        );

        header.add(
                title,
                BorderLayout.WEST
        );

        header.add(
                tag,
                BorderLayout.EAST
        );

        // TOP

        JPanel top =
                new JPanel(
                        new FlowLayout()
                );

        top.setOpaque(false);

        btnLoad =
                new JButton(
                        "▶  TẢI SẢN PHẨM"
                );

        styleButton(
                btnLoad,
                TEAL
        );

        top.add(btnLoad);

        // TABLE

        table =
                new JTable();

        table.setModel(
                new DefaultTableModel(
                        new Object[]{
                                "Mã SP",
                                "Tên SP",
                                "Đơn giá"
                        },
                        0
                )
        );

        table.setRowHeight(32);

        table.setFont(
                new Font(
                        "Segoe UI",
                        Font.PLAIN,
                        14
                )
        );

        table.getTableHeader()
                .setFont(
                        new Font(
                                "Segoe UI",
                                Font.BOLD,
                                14
                        )
                );

        JScrollPane scroll =
                new JScrollPane(table);

        // BOTTOM

        JPanel bottom =
                new JPanel();

        bottom.setLayout(
                new BoxLayout(
                        bottom,
                        BoxLayout.Y_AXIS
                )
        );

        bottom.setBorder(
                new EmptyBorder(
                        10, 30, 20, 30
                )
        );

        bottom.setOpaque(false);

        progressBar =
                new JProgressBar(
                        0,
                        100
                );

        progressBar.setStringPainted(true);

        progressBar.setForeground(TEAL);

        lblStatus =
                new JLabel(
                        "Sẵn sàng"
                );

        lblStatus.setAlignmentX(
                Component.CENTER_ALIGNMENT
        );

        lblStatus.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        14
                )
        );

        bottom.add(lblStatus);

        bottom.add(
                Box.createVerticalStrut(8)
        );

        bottom.add(progressBar);

        main.add(
                header,
                BorderLayout.NORTH
        );

        main.add(
                top,
                BorderLayout.PAGE_START
        );

        main.add(
                scroll,
                BorderLayout.CENTER
        );

        main.add(
                bottom,
                BorderLayout.SOUTH
        );

        add(main);

        btnLoad.addActionListener(
                e -> loadProducts()
        );
    }

    private void styleButton(
            JButton button,
            Color color
    ) {

        button.setForeground(Color.WHITE);

        button.setBackground(color);

        button.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        13
                )
        );

        button.setFocusPainted(false);

        button.setBorderPainted(false);
    }

    private void loadProducts() {

        btnLoad.setEnabled(false);

        DefaultTableModel model =
                (DefaultTableModel)
                        table.getModel();

        model.setRowCount(0);

        progressBar.setValue(0);

        lblStatus.setText(
                "Đang tải sản phẩm..."
        );

        SwingWorker<Void, Product> worker =
                new SwingWorker<>() {

                    @Override
                    protected Void doInBackground()
                            throws Exception {

                        Product[] products = {

                                new Product(
                                        "SP01",
                                        "Bàn phím",
                                        250000
                                ),

                                new Product(
                                        "SP02",
                                        "Chuột",
                                        150000
                                ),

                                new Product(
                                        "SP03",
                                        "Màn hình",
                                        2500000
                                ),

                                new Product(
                                        "SP04",
                                        "Tai nghe",
                                        450000
                                ),

                                new Product(
                                        "SP05",
                                        "Webcam",
                                        650000
                                )
                        };

                        for (
                                int i = 0;
                                i < products.length;
                                i++
                        ) {

                            Thread.sleep(800);

                            publish(
                                    products[i]
                            );

                            setProgress(
                                    (
                                            (i + 1)
                                                    * 100
                                    )
                                            / products.length
                            );
                        }

                        return null;
                    }

                    @Override
                    protected void process(
                            java.util.List<Product> chunks
                    ) {

                        for (
                                Product p :
                                chunks
                        ) {

                            model.addRow(
                                    new Object[]{
                                            p.id,
                                            p.name,
                                            String.format(
                                                    "%,.0f VNĐ",
                                                    p.price
                                            )
                                    }
                            );
                        }
                    }

                    @Override
                    protected void done() {

                        progressBar.setValue(
                                100
                        );

                        lblStatus.setText(
                                "✓ Đã tải sản phẩm thành công"
                        );

                        btnLoad.setEnabled(true);
                    }
                };

        worker.addPropertyChangeListener(
                evt -> {

                    if (
                            "progress".equals(
                                    evt.getPropertyName()
                            )
                    ) {

                        progressBar.setValue(
                                (int) evt.getNewValue()
                        );
                    }
                }
        );

        worker.execute();
    }

    private static class Product {

        String id;
        String name;
        double price;

        Product(
                String id,
                String name,
                double price
        ) {

            this.id = id;
            this.name = name;
            this.price = price;
        }
    }
}