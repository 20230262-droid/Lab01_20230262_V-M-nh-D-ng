package vn.edu.eaut.lab14.controller;

import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import vn.edu.eaut.lab14.model.Student;
import vn.edu.eaut.lab14.repository.StudentRepository;

@Controller
@RequestMapping("/students")
public class StudentController {
    private final StudentRepository repository;

    public StudentController(StudentRepository repository) {
        this.repository = repository;
    }

    @GetMapping
    public String list(Model model) {
        model.addAttribute("students", repository.findAll());
        return "students/list";
    }

    @GetMapping("/create")
    public String createForm(Model model) {
        model.addAttribute("student", new Student());
        model.addAttribute("pageTitle", "Thêm sinh viên");
        return "students/form";
    }

    @PostMapping("/save")
    public String save(@Valid @ModelAttribute("student") Student student,
                       BindingResult result, Model model) {
        if (result.hasErrors()) {
            model.addAttribute("pageTitle", student.getId() == null ? "Thêm sinh viên" : "Chỉnh sửa sinh viên");
            return "students/form";
        }
        repository.save(student);
        return "redirect:/students";
    }

    @GetMapping("/edit/{id}")
    public String editForm(@PathVariable Long id, Model model) {
        model.addAttribute("student", repository.findById(id).orElseThrow());
        model.addAttribute("pageTitle", "Chỉnh sửa sinh viên");
        return "students/form";
    }

    @PostMapping("/delete/{id}")
    public String delete(@PathVariable Long id) {
        repository.deleteById(id);
        return "redirect:/students";
    }
}
