package vn.edu.eaut.lab4;

import javax.swing.*;
import java.awt.*;

public class Bai03_PrimeSumFrame extends JFrame {

    private JTextField txtN;
    private JButton btnCalculate;
    private JLabel lblResult;
    private JProgressBar progressBar;

    public Bai03_PrimeSumFrame() {

        UIStyle.setupFrame(
                this,
                "Bài 3 - Tính tổng số nguyên tố"
        );

        initUI();
    }

    private void initUI() {

        JPanel mainPanel = new JPanel(
                new BorderLayout(15, 15)
        );

        mainPanel.setBackground(
                UIStyle.BACKGROUND
        );

        mainPanel.setBorder(
                BorderFactory.createEmptyBorder(
                        25,
                        35,
                        25,
                        35
                )
        );

        // =========================
        // HEADER
        // =========================

        JLabel title =
                UIStyle.createTitle(
                        "✦ BÀI 3 - SỐ NGUYÊN TỐ ✦"
                );

        JLabel subtitle =
                UIStyle.createSubtitle(
                        "Tính tổng các số nguyên tố nhỏ hơn N"
                );

        JPanel header = new JPanel(
                new GridLayout(2, 1)
        );

        header.setOpaque(false);

        header.add(title);
        header.add(subtitle);

        mainPanel.add(
                header,
                BorderLayout.NORTH
        );


        // =========================
        // CARD
        // =========================

        JPanel card =
                UIStyle.createCard();

        card.setLayout(
                new GridBagLayout()
        );

        GridBagConstraints gbc =
                new GridBagConstraints();

        gbc.insets =
                new Insets(10, 10, 10, 10);

        gbc.fill =
                GridBagConstraints.HORIZONTAL;


        // Nhập N
        JLabel lblN =
                UIStyle.createLabel(
                        "Nhập N:"
                );

        txtN =
                UIStyle.createTextField();

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 0;

        card.add(
                lblN,
                gbc
        );

        gbc.gridx = 1;
        gbc.weightx = 1;

        card.add(
                txtN,
                gbc
        );


        // Button
        btnCalculate =
                UIStyle.createButton(
                        "Tính tổng"
                );

        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 2;
        gbc.weightx = 1;

        card.add(
                btnCalculate,
                gbc
        );


        // Progress
        progressBar =
                new JProgressBar(
                        0,
                        100
                );

        UIStyle.styleProgressBar(
                progressBar
        );

        gbc.gridy = 2;

        card.add(
                progressBar,
                gbc
        );


        // Result
        lblResult =
                UIStyle.createResultLabel();

        gbc.gridy = 3;

        card.add(
                lblResult,
                gbc
        );


        mainPanel.add(
                card,
                BorderLayout.CENTER
        );


        // =========================
        // EVENT
        // =========================

        btnCalculate.addActionListener(
                e -> calculatePrimeSum()
        );


        // ENTER để tính
        txtN.addActionListener(
                e -> calculatePrimeSum()
        );


        setContentPane(mainPanel);
    }


    // =========================
    // KIỂM TRA SỐ NGUYÊN TỐ
    // =========================

    private boolean isPrime(int n) {

        if (n < 2) {
            return false;
        }

        if (n == 2) {
            return true;
        }

        if (n % 2 == 0) {
            return false;
        }

        for (
                int i = 3;
                i <= Math.sqrt(n);
                i += 2
        ) {

            if (n % i == 0) {
                return false;
            }
        }

        return true;
    }


    // =========================
    // TÍNH TỔNG
    // =========================

    private void calculatePrimeSum() {

        int n;

        try {

            n = Integer.parseInt(
                    txtN.getText().trim()
            );

            if (n <= 2) {

                JOptionPane.showMessageDialog(
                        this,
                        "N phải lớn hơn 2!",
                        "Thông báo",
                        JOptionPane.WARNING_MESSAGE
                );

                return;
            }

        } catch (NumberFormatException ex) {

            JOptionPane.showMessageDialog(
                    this,
                    "Vui lòng nhập số nguyên hợp lệ!",
                    "Lỗi",
                    JOptionPane.ERROR_MESSAGE
            );

            return;
        }


        btnCalculate.setEnabled(false);

        progressBar.setValue(0);

        lblResult.setText(
                "Đang tính toán..."
        );


        SwingWorker<Long, Void> worker =
                new SwingWorker<>() {

                    @Override
                    protected Long doInBackground() {

                        long sum = 0;

                        for (
                                int i = 2;
                                i < n;
                                i++
                        ) {

                            if (isPrime(i)) {

                                sum += i;
                            }

                            int progress =
                                    (int)
                                            ((i * 100.0) / n);

                            setProgress(progress);
                        }

                        return sum;
                    }


                    @Override
                    protected void done() {

                        try {

                            long result = get();

                            lblResult.setText(
                                    "✓ Tổng = " + result
                            );

                        } catch (Exception ex) {

                            lblResult.setText(
                                    "Có lỗi khi tính toán!"
                            );
                        }

                        progressBar.setValue(100);

                        btnCalculate.setEnabled(true);
                    }
                };


        worker.addPropertyChangeListener(
                evt -> {

                    if (
                            "progress".equals(
                                    evt.getPropertyName()
                            )
                    ) {

                        progressBar.setValue(
                                (int) evt.getNewValue()
                        );
                    }
                }
        );


        worker.execute();
    }


    public static void main(String[] args) {

        SwingUtilities.invokeLater(
                () -> {

                    new Bai03_PrimeSumFrame()
                            .setVisible(true);
                }
        );
    }
}