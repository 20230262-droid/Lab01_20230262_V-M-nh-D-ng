package vn.edu.eaut.lab13.entity;
import jakarta.persistence.*; import jakarta.validation.constraints.*;
@Entity @Table(name="students") public class Student {
@Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
@NotBlank(message="Mã sinh viên không được để trống") @Column(name="student_code",nullable=false,unique=true) private String studentCode;
@NotBlank(message="Họ tên không được để trống") @Column(name="full_name",nullable=false) private String fullName;
@Email(message="Email không đúng định dạng") private String email; @Column(name="class_name") private String className;
public Student(){} public Long getId(){return id;} public void setId(Long id){this.id=id;} public String getStudentCode(){return studentCode;} public void setStudentCode(String v){studentCode=v;} public String getFullName(){return fullName;} public void setFullName(String v){fullName=v;} public String getEmail(){return email;} public void setEmail(String v){email=v;} public String getClassName(){return className;} public void setClassName(String v){className=v;}
}
