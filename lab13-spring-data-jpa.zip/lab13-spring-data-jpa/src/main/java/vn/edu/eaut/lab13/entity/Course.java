package vn.edu.eaut.lab13.entity;
import jakarta.persistence.*; import jakarta.validation.constraints.*;
@Entity @Table(name="courses") public class Course {
@Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
@NotBlank(message="Mã môn không được để trống") @Column(name="course_code",nullable=false,unique=true) private String courseCode;
@NotBlank(message="Tên môn không được để trống") @Column(name="course_name",nullable=false) private String courseName;
@Min(value=1,message="Số tín chỉ phải lớn hơn 0") private Integer credits;
public Course(){} public Long getId(){return id;} public void setId(Long id){this.id=id;} public String getCourseCode(){return courseCode;} public void setCourseCode(String v){courseCode=v;} public String getCourseName(){return courseName;} public void setCourseName(String v){courseName=v;} public Integer getCredits(){return credits;} public void setCredits(Integer v){credits=v;}
}
