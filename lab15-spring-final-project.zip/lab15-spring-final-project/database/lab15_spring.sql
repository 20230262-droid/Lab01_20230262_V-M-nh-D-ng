CREATE DATABASE IF NOT EXISTS lab15_spring
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE lab15_spring;

-- Spring Boot có thể tự tạo/cập nhật bảng nhờ spring.jpa.hibernate.ddl-auto=update.
-- Các câu lệnh dưới đây dùng để tạo dữ liệu mẫu sau khi ứng dụng đã chạy lần đầu.

INSERT INTO students (student_code, full_name, email, phone, major) VALUES
('SV2026001','Nguyễn Minh Anh','minhanh@eaut.edu.vn','0901234567','Công nghệ thông tin'),
('SV2026002','Trần Hoàng Nam','hoangnam@eaut.edu.vn','0912345678','Kỹ thuật phần mềm'),
('SV2026003','Lê Thu Hà','thuha@eaut.edu.vn','0923456789','Hệ thống thông tin');

INSERT INTO courses (course_code, course_name, credits) VALUES
('JAVA101','Công nghệ Java',3),
('SPRING01','Phát triển ứng dụng với Spring Framework',3),
('DBMS101','Cơ sở dữ liệu',3),
('WEB201','Lập trình Web',4);
