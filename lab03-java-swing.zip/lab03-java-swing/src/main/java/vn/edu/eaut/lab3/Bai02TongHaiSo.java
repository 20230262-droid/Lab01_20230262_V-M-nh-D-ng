package vn.edu.eaut.lab3;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class Bai02TongHaiSo extends JFrame {

    private final JTextField txtA = new JTextField();
    private final JTextField txtB = new JTextField();
    private final JLabel lblResult = new JLabel("Kết quả: —");

    private final Color BLUE = new Color(25, 118, 210);
    private final Color DARK_BLUE = new Color(13, 71, 161);
    private final Color BG = new Color(245, 248, 252);

    public Bai02TongHaiSo() {

        setTitle("Bài 2 - Tính tổng hai số");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(600, 480);
        setLocationRelativeTo(null);
        setResizable(false);

        JPanel main = new JPanel(new BorderLayout());
        main.setBackground(BG);

        // HEADER
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(DARK_BLUE);
        header.setBorder(new EmptyBorder(22, 28, 22, 28));

        JLabel title = new JLabel("TÍNH TỔNG HAI SỐ");
        title.setFont(new Font("Arial", Font.BOLD, 26));
        title.setForeground(Color.WHITE);

        JLabel subtitle = new JLabel("Nhập hai số và tính tổng nhanh chóng");
        subtitle.setFont(new Font("Arial", Font.PLAIN, 13));
        subtitle.setForeground(new Color(220, 235, 255));

        JPanel box = new JPanel();
        box.setOpaque(false);
        box.setLayout(new BoxLayout(box, BoxLayout.Y_AXIS));
        box.add(title);
        box.add(Box.createVerticalStrut(5));
        box.add(subtitle);

        header.add(box, BorderLayout.WEST);

        JLabel icon = new JLabel("➕");
        icon.setFont(new Font("Arial", Font.BOLD, 38));
        header.add(icon, BorderLayout.EAST);

        main.add(header, BorderLayout.NORTH);

        // FORM
        JPanel card = new JPanel(new GridBagLayout());
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(215, 225, 238)),
                new EmptyBorder(25, 30, 25, 30)
        ));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel la = createLabel("Số thứ nhất");
        JLabel lb = createLabel("Số thứ hai");

        styleField(txtA);
        styleField(txtB);

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 0;
        card.add(la, gbc);

        gbc.gridx = 1;
        gbc.weightx = 1;
        card.add(txtA, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.weightx = 0;
        card.add(lb, gbc);

        gbc.gridx = 1;
        gbc.weightx = 1;
        card.add(txtB, gbc);

        JButton btnSum = createButton("➕  TÍNH TỔNG", BLUE);
        JButton btnClear = createButton("↻  LÀM MỚI", new Color(100, 116, 139));

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 5));
        buttons.setOpaque(false);
        buttons.add(btnSum);
        buttons.add(btnClear);

        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        card.add(buttons, gbc);

        // RESULT
        lblResult.setFont(new Font("Arial", Font.BOLD, 19));
        lblResult.setForeground(DARK_BLUE);
        lblResult.setHorizontalAlignment(SwingConstants.CENTER);

        gbc.gridy = 3;
        card.add(lblResult, gbc);

        JPanel center = new JPanel(new GridBagLayout());
        center.setBackground(BG);
        center.setBorder(new EmptyBorder(25, 30, 25, 30));
        center.add(card);

        main.add(center, BorderLayout.CENTER);

        add(main);

        btnSum.addActionListener(e -> tinhTong());
        btnClear.addActionListener(e -> lamMoi());
    }

    private JLabel createLabel(String text) {

        JLabel label = new JLabel(text);
        label.setFont(new Font("Arial", Font.BOLD, 14));
        label.setForeground(new Color(45, 55, 70));
        return label;
    }

    private void styleField(JTextField field) {

        field.setFont(new Font("Arial", Font.PLAIN, 15));
        field.setPreferredSize(new Dimension(300, 40));
        field.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(190, 205, 225)),
                new EmptyBorder(8, 12, 8, 12)
        ));
    }

    private JButton createButton(String text, Color color) {

        JButton button = new JButton(text);
        button.setFont(new Font("Arial", Font.BOLD, 12));
        button.setForeground(Color.WHITE);
        button.setBackground(color);
        button.setPreferredSize(new Dimension(145, 42));
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return button;
    }

    private void tinhTong() {

        try {

            double a = Double.parseDouble(txtA.getText().trim());
            double b = Double.parseDouble(txtB.getText().trim());

            lblResult.setText(
                    String.format("Kết quả: %.2f", a + b)
            );

        } catch (NumberFormatException ex) {

            JOptionPane.showMessageDialog(
                    this,
                    "Dữ liệu nhập phải là số hợp lệ!",
                    "Lỗi dữ liệu",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    private void lamMoi() {

        txtA.setText("");
        txtB.setText("");
        lblResult.setText("Kết quả: —");
        txtA.requestFocus();
    }

    public static void main(String[] args) {

        SwingUtilities.invokeLater(() ->
                new Bai02TongHaiSo().setVisible(true)
        );
    }
}