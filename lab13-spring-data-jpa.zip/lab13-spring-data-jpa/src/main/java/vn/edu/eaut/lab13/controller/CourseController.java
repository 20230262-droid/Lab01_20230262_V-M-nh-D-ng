package vn.edu.eaut.lab13.controller;
import jakarta.validation.Valid; import org.springframework.stereotype.Controller; import org.springframework.ui.Model; import org.springframework.validation.BindingResult; import org.springframework.web.bind.annotation.*; import vn.edu.eaut.lab13.entity.Course; import vn.edu.eaut.lab13.service.CourseService;
@Controller @RequestMapping("/courses") public class CourseController { private final CourseService service; public CourseController(CourseService s){service=s;}
@GetMapping public String list(@RequestParam(required=false)String keyword,Model m){m.addAttribute("courses",service.search(keyword));m.addAttribute("keyword",keyword);return "courses/list";}
@GetMapping("/create") public String create(Model m){m.addAttribute("course",new Course());m.addAttribute("pageTitle","Thêm môn học");return "courses/form";}
@GetMapping("/edit/{id}") public String edit(@PathVariable Long id,Model m){m.addAttribute("course",service.findById(id));m.addAttribute("pageTitle","Sửa môn học");return "courses/form";}
@PostMapping("/save") public String save(@Valid @ModelAttribute("course")Course c,BindingResult r,Model m){if(service.existsCode(c.getCourseCode(),c.getId()))r.rejectValue("courseCode","duplicate","Mã môn đã tồn tại");if(r.hasErrors()){m.addAttribute("pageTitle",c.getId()==null?"Thêm môn học":"Sửa môn học");return "courses/form";}service.save(c);return "redirect:/courses";}
@GetMapping("/delete/{id}") public String delete(@PathVariable Long id){service.deleteById(id);return "redirect:/courses";}}
