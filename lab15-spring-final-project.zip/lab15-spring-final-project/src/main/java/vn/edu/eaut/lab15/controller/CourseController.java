package vn.edu.eaut.lab15.controller;

import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import vn.edu.eaut.lab15.entity.Course;
import vn.edu.eaut.lab15.service.CourseService;

@Controller
@RequestMapping("/courses")
public class CourseController {
    private final CourseService service;

    public CourseController(CourseService service) {
        this.service = service;
    }

    @GetMapping
    public String list(@RequestParam(required = false) String keyword, Model model) {
        model.addAttribute("courses", service.search(keyword));
        model.addAttribute("keyword", keyword == null ? "" : keyword);
        return "courses/list";
    }

    @GetMapping("/new")
    public String create(Model model) {
        model.addAttribute("course", new Course());
        model.addAttribute("pageTitle", "Thêm môn học");
        return "courses/form";
    }

    @GetMapping("/edit/{id}")
    public String edit(@PathVariable Long id, Model model) {
        model.addAttribute("course", service.findById(id));
        model.addAttribute("pageTitle", "Chỉnh sửa môn học");
        return "courses/form";
    }

    @PostMapping("/save")
    public String save(@Valid @ModelAttribute Course course, BindingResult result, Model model) {
        if (result.hasErrors()) {
            model.addAttribute("pageTitle", course.getId() == null ? "Thêm môn học" : "Chỉnh sửa môn học");
            return "courses/form";
        }
        service.save(course);
        return "redirect:/courses?success=1";
    }

    @GetMapping("/delete/{id}")
    public String delete(@PathVariable Long id) {
        service.delete(id);
        return "redirect:/courses?deleted=1";
    }
}
