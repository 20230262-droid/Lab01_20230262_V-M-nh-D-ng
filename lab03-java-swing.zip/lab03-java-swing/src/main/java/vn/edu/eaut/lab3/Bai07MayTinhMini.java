package vn.edu.eaut.lab3;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class Bai07MayTinhMini extends JFrame {

    private final JTextField txtA =
            new JTextField();

    private final JTextField txtB =
            new JTextField();

    private final JLabel lblResult =
            new JLabel("Kết quả: —");

    private final JTextArea txtHistory =
            new JTextArea();


    private final Color BLUE =
            new Color(25, 118, 210);

    private final Color DARK_BLUE =
            new Color(13, 71, 161);

    private final Color BG =
            new Color(245, 248, 252);


    public Bai07MayTinhMini() {

        setTitle(
                "Bài 7 - Máy tính Mini"
        );

        setDefaultCloseOperation(
                JFrame.EXIT_ON_CLOSE
        );

        setSize(
                850,
                620
        );

        setLocationRelativeTo(null);

        setResizable(false);


        JPanel main =
                new JPanel(
                        new BorderLayout()
                );

        main.setBackground(BG);


        // HEADER

        JPanel header =
                new JPanel(
                        new BorderLayout()
                );

        header.setBackground(
                DARK_BLUE
        );

        header.setBorder(
                new EmptyBorder(
                        20,
                        28,
                        20,
                        28
                )
        );


        JLabel title =
                new JLabel(
                        "MÁY TÍNH MINI"
                );

        title.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        27
                )
        );

        title.setForeground(
                Color.WHITE
        );


        JLabel subtitle =
                new JLabel(
                        "Cộng • Trừ • Nhân • Chia"
                );

        subtitle.setFont(
                new Font(
                        "Arial",
                        Font.PLAIN,
                        13
                )
        );

        subtitle.setForeground(
                new Color(
                        220,
                        235,
                        255
                )
        );


        JPanel titleBox =
                new JPanel();

        titleBox.setOpaque(false);

        titleBox.setLayout(
                new BoxLayout(
                        titleBox,
                        BoxLayout.Y_AXIS
                )
        );

        titleBox.add(title);

        titleBox.add(
                Box.createVerticalStrut(5)
        );

        titleBox.add(subtitle);


        header.add(
                titleBox,
                BorderLayout.WEST
        );


        JLabel icon =
                new JLabel("🧮");

        icon.setFont(
                new Font(
                        "Segoe UI Emoji",
                        Font.PLAIN,
                        42
                )
        );

        header.add(
                icon,
                BorderLayout.EAST
        );


        main.add(
                header,
                BorderLayout.NORTH
        );


        // LEFT CARD

        JPanel calculatorCard =
                new JPanel(
                        new GridBagLayout()
                );

        calculatorCard.setBackground(
                Color.WHITE
        );

        calculatorCard.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(
                                new Color(
                                        215,
                                        225,
                                        238
                                )
                        ),
                        new EmptyBorder(
                                20,
                                20,
                                20,
                                20
                        )
                )
        );


        GridBagConstraints gbc =
                new GridBagConstraints();

        gbc.insets =
                new Insets(
                        7,
                        7,
                        7,
                        7
                );

        gbc.fill =
                GridBagConstraints.HORIZONTAL;


        JLabel titleCalc =
                new JLabel(
                        "NHẬP DỮ LIỆU"
                );

        titleCalc.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        16
                )
        );

        titleCalc.setForeground(
                DARK_BLUE
        );


        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;

        calculatorCard.add(
                titleCalc,
                gbc
        );


        gbc.gridwidth = 1;


        calculatorCard.add(
                createLabel(
                        "Số thứ nhất"
                ),
                setPosition(
                        gbc,
                        0,
                        1
                )
        );


        styleField(txtA);

        calculatorCard.add(
                txtA,
                setPosition(
                        gbc,
                        1,
                        1
                )
        );


        calculatorCard.add(
                createLabel(
                        "Số thứ hai"
                ),
                setPosition(
                        gbc,
                        0,
                        2
                )
        );


        styleField(txtB);

        calculatorCard.add(
                txtB,
                setPosition(
                        gbc,
                        1,
                        2
                )
        );


        JButton btnAdd =
                createButton(
                        "+  CỘNG",
                        BLUE
                );

        JButton btnSub =
                createButton(
                        "−  TRỪ",
                        new Color(
                                0,
                                150,
                                136
                        )
                );

        JButton btnMul =
                createButton(
                        "×  NHÂN",
                        new Color(
                                123,
                                31,
                                162
                        )
                );

        JButton btnDiv =
                createButton(
                        "÷  CHIA",
                        new Color(
                                230,
                                126,
                                34
                        )
                );


        JPanel operations =
                new JPanel(
                        new GridLayout(
                                2,
                                2,
                                8,
                                8
                        )
                );

        operations.setOpaque(false);

        operations.add(btnAdd);
        operations.add(btnSub);
        operations.add(btnMul);
        operations.add(btnDiv);


        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;

        calculatorCard.add(
                operations,
                gbc
        );


        lblResult.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        20
                )
        );

        lblResult.setForeground(
                DARK_BLUE
        );

        lblResult.setHorizontalAlignment(
                SwingConstants.CENTER
        );


        gbc.gridy = 4;

        calculatorCard.add(
                lblResult,
                gbc
        );


        JButton btnClear =
                createButton(
                        "↻  CLEAR",
                        new Color(
                                100,
                                116,
                                139
                        )
                );


        gbc.gridy = 5;

        calculatorCard.add(
                btnClear,
                gbc
        );


        // HISTORY

        JPanel historyCard =
                new JPanel(
                        new BorderLayout(
                                10,
                                10
                        )
                );

        historyCard.setBackground(
                Color.WHITE
        );

        historyCard.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(
                                new Color(
                                        215,
                                        225,
                                        238
                                )
                        ),
                        new EmptyBorder(
                                15,
                                15,
                                15,
                                15
                        )
                )
        );


        JLabel historyTitle =
                new JLabel(
                        "LỊCH SỬ PHÉP TÍNH"
                );

        historyTitle.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        16
                )
        );

        historyTitle.setForeground(
                DARK_BLUE
        );


        txtHistory.setEditable(false);

        txtHistory.setFont(
                new Font(
                        "Consolas",
                        Font.PLAIN,
                        13
                )
        );

        txtHistory.setLineWrap(true);

        txtHistory.setWrapStyleWord(true);

        txtHistory.setBackground(
                new Color(
                        250,
                        252,
                        255
                )
        );


        JScrollPane scroll =
                new JScrollPane(
                        txtHistory
                );

        scroll.setBorder(
                BorderFactory.createLineBorder(
                        new Color(
                                215,
                                225,
                                238
                        )
                )
        );


        historyCard.add(
                historyTitle,
                BorderLayout.NORTH
        );

        historyCard.add(
                scroll,
                BorderLayout.CENTER
        );


        JPanel content =
                new JPanel(
                        new GridLayout(
                                1,
                                2,
                                15,
                                0
                        )
                );

        content.setBackground(BG);

        content.setBorder(
                new EmptyBorder(
                        20,
                        20,
                        20,
                        20
                )
        );


        content.add(
                calculatorCard
        );

        content.add(
                historyCard
        );


        main.add(
                content,
                BorderLayout.CENTER
        );


        add(main);


        // EVENTS

        btnAdd.addActionListener(
                e -> tinh('+')
        );

        btnSub.addActionListener(
                e -> tinh('-')
        );

        btnMul.addActionListener(
                e -> tinh('*')
        );

        btnDiv.addActionListener(
                e -> tinh('/')
        );

        btnClear.addActionListener(
                e -> lamMoi()
        );
    }


    private GridBagConstraints setPosition(
            GridBagConstraints gbc,
            int x,
            int y
    ) {

        gbc.gridx = x;
        gbc.gridy = y;
        gbc.weightx =
                x == 1 ? 1 : 0;

        return gbc;
    }


    private JLabel createLabel(
            String text
    ) {

        JLabel label =
                new JLabel(text);

        label.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        13
                )
        );

        label.setForeground(
                new Color(
                        45,
                        55,
                        70
                )
        );

        return label;
    }


    private void styleField(
            JTextField field
    ) {

        field.setFont(
                new Font(
                        "Arial",
                        Font.PLAIN,
                        14
                )
        );

        field.setPreferredSize(
                new Dimension(
                        190,
                        38
                )
        );

        field.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(
                                new Color(
                                        190,
                                        205,
                                        225
                                )
                        ),
                        new EmptyBorder(
                                7,
                                10,
                                7,
                                10
                        )
                )
        );
    }


    private JButton createButton(
            String text,
            Color color
    ) {

        JButton button =
                new JButton(text);

        button.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        11
                )
        );

        button.setForeground(
                Color.WHITE
        );

        button.setBackground(
                color
        );

        button.setFocusPainted(false);

        button.setBorderPainted(false);

        button.setCursor(
                new Cursor(
                        Cursor.HAND_CURSOR
                )
        );

        return button;
    }


    private void tinh(
            char operator
    ) {

        try {

            double a =
                    Double.parseDouble(
                            txtA.getText().trim()
                    );

            double b =
                    Double.parseDouble(
                            txtB.getText().trim()
                    );


            double result;


            switch (operator) {

                case '+':

                    result = a + b;

                    break;

                case '-':

                    result = a - b;

                    break;

                case '*':

                    result = a * b;

                    break;

                case '/':

                    if (b == 0) {

                        JOptionPane.showMessageDialog(
                                this,
                                "Không thể chia cho 0!",
                                "Lỗi phép tính",
                                JOptionPane.ERROR_MESSAGE
                        );

                        return;
                    }

                    result = a / b;

                    break;

                default:

                    return;
            }


            lblResult.setText(
                    String.format(
                            "Kết quả: %.4f",
                            result
                    )
            );


            txtHistory.append(
                    String.format(
                            "%.4f %c %.4f = %.4f%n",
                            a,
                            operator,
                            b,
                            result
                    )
            );


        } catch (
                NumberFormatException ex
        ) {

            JOptionPane.showMessageDialog(
                    this,
                    "Vui lòng nhập hai số hợp lệ!",
                    "Lỗi dữ liệu",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }


    private void lamMoi() {

        txtA.setText("");

        txtB.setText("");

        lblResult.setText(
                "Kết quả: —"
        );

        txtHistory.setText("");

        txtA.requestFocus();
    }


    public static void main(
            String[] args
    ) {

        SwingUtilities.invokeLater(
                () ->
                        new Bai07MayTinhMini()
                                .setVisible(true)
        );
    }
}