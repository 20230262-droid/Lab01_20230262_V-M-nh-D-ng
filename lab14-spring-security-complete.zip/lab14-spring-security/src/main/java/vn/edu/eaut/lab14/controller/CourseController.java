package vn.edu.eaut.lab14.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import java.util.List;

@Controller
public class CourseController {
    @GetMapping("/courses")
    public String courses(Model model) {
        model.addAttribute("courses", List.of(
            "Spring Framework & Spring Boot",
            "Spring Security",
            "Spring MVC",
            "Spring Data JPA",
            "Thymeleaf"
        ));
        return "courses/list";
    }
}
