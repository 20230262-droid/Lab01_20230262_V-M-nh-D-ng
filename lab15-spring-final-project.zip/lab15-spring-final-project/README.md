# LAB 15 - SPRING FINAL PROJECT

Ứng dụng tổng hợp Chương 4: Spring Boot + Spring MVC + Thymeleaf + Spring Data JPA + Spring Security.

## 1. Chức năng
- Login / Logout.
- Phân quyền ADMIN / USER.
- Dashboard thống kê.
- CRUD sinh viên + tìm kiếm.
- CRUD môn học + tìm kiếm.
- Đăng ký học phần, chống đăng ký trùng.
- Hủy đăng ký.
- Xem các học phần của một sinh viên.
- Validation form.
- Giao diện responsive, hiện đại.

## 2. Tài khoản demo
- ADMIN: `admin` / `123456`
- USER: `user` / `123456`

ADMIN được vào toàn bộ chức năng quản lý.
USER chỉ xem Dashboard.

## 3. CSDL
1. Mở MySQL/phpMyAdmin.
2. Chạy file `database/lab15_spring.sql` để tạo database và dữ liệu mẫu.
3. Nếu MySQL có mật khẩu, sửa `spring.datasource.password` trong `src/main/resources/application.properties`.

## 4. Chạy project
```powershell
cd lab15-spring-final-project
mvn clean package
mvn spring-boot:run
```
Mở: http://localhost:8080

## 5. Nếu máy dùng Java 21
Có thể đổi `<java.version>` trong pom.xml từ 17 thành 21. Project dùng Spring Boot 3.5.x và Jakarta APIs.

## 6. Cấu trúc
- config: Spring Security
- controller: MVC Controller
- entity: JPA Entity
- repository: Spring Data JPA
- service: nghiệp vụ
- templates: Thymeleaf
- static/css: giao diện
- database: SQL
