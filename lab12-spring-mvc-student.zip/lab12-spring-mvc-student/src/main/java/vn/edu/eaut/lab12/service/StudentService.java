package vn.edu.eaut.lab12.service;

import org.springframework.stereotype.Service;
import vn.edu.eaut.lab12.model.Student;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class StudentService {
    private final List<Student> students = new ArrayList<>();
    private long nextId = 1;

    public StudentService() {
        students.add(new Student(nextId++, "SV001", "Nguyễn Văn An", "an@gmail.com", "K14-CNTT"));
        students.add(new Student(nextId++, "SV002", "Trần Thị Bình", "binh@gmail.com", "K14-CNTT"));
        students.add(new Student(nextId++, "SV003", "Lê Văn Cường", "cuong@gmail.com", "K14-CNTT"));
    }

    public List<Student> findAll() {
        return students;
    }

    public Optional<Student> findById(Long id) {
        return students.stream().filter(s -> s.getId().equals(id)).findFirst();
    }

    public void save(Student student) {
        if (student.getId() == null) {
            student.setId(nextId++);
            students.add(student);
        } else {
            Student existing = findById(student.getId())
                    .orElseThrow(() -> new IllegalArgumentException("Không tìm thấy sinh viên"));
            existing.setStudentCode(student.getStudentCode());
            existing.setFullName(student.getFullName());
            existing.setEmail(student.getEmail());
            existing.setClassName(student.getClassName());
        }
    }

    public void delete(Long id) {
        students.removeIf(s -> s.getId().equals(id));
    }

    public List<Student> search(String keyword) {
        if (keyword == null || keyword.trim().isEmpty()) return students;
        String key = keyword.toLowerCase().trim();
        return students.stream()
                .filter(s -> s.getStudentCode().toLowerCase().contains(key)
                        || s.getFullName().toLowerCase().contains(key)
                        || s.getClassName().toLowerCase().contains(key))
                .toList();
    }

    public boolean existsStudentCode(String studentCode, Long excludeId) {
        return students.stream().anyMatch(s ->
                s.getStudentCode().equalsIgnoreCase(studentCode)
                        && !s.getId().equals(excludeId));
    }
}
