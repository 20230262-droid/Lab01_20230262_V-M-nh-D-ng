package vn.edu.eaut.lab14;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import vn.edu.eaut.lab14.model.Student;
import vn.edu.eaut.lab14.repository.StudentRepository;

@SpringBootApplication
public class Lab14Application {
    public static void main(String[] args) {
        SpringApplication.run(Lab14Application.class, args);
    }

    @Bean
    CommandLineRunner seedData(StudentRepository repository) {
        return args -> {
            if (repository.count() == 0) {
                repository.save(new Student(null, "SV001", "Nguyễn Văn An", "an@example.com", "Công nghệ thông tin", 3.62));
                repository.save(new Student(null, "SV002", "Trần Minh Anh", "anh@example.com", "Kỹ thuật phần mềm", 3.45));
                repository.save(new Student(null, "SV003", "Lê Hoàng Nam", "nam@example.com", "Hệ thống thông tin", 3.28));
            }
        };
    }
}
