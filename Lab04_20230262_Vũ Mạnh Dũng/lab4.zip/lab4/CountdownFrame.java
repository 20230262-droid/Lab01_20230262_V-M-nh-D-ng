package vn.edu.eaut.lab4;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class CountdownFrame extends JFrame {

    private JLabel lblTime;
    private JLabel lblStatus;

    private JButton btnStart;
    private JButton btnReset;

    private int seconds = 10;

    private final Color PURPLE =
            new Color(88, 28, 135);

    private final Color TEAL =
            new Color(13, 148, 136);

    private final Color DARK =
            new Color(46, 16, 73);

    private final Color BG =
            new Color(245, 243, 249);

    public CountdownFrame() {

        setTitle("Countdown - SwingWorker");

        setSize(620, 500);

        setLocationRelativeTo(null);

        setDefaultCloseOperation(
                JFrame.DISPOSE_ON_CLOSE
        );

        initUI();
    }

    private void initUI() {

        JPanel main =
                new JPanel(
                        new BorderLayout()
                );

        main.setBackground(BG);

        // HEADER

        JPanel header =
                new JPanel(
                        new BorderLayout()
                );

        header.setBackground(DARK);

        header.setBorder(
                new EmptyBorder(
                        22, 30, 22, 30
                )
        );

        JLabel title =
                new JLabel(
                        "COUNTDOWN"
                );

        title.setForeground(
                Color.WHITE
        );

        title.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        25
                )
        );

        JLabel tag =
                new JLabel(
                        "SWINGWORKER"
                );

        tag.setForeground(
                new Color(153, 246, 228)
        );

        tag.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        13
                )
        );

        header.add(
                title,
                BorderLayout.WEST
        );

        header.add(
                tag,
                BorderLayout.EAST
        );

        // CONTENT

        JPanel center =
                new JPanel();

        center.setOpaque(false);

        center.setLayout(
                new BoxLayout(
                        center,
                        BoxLayout.Y_AXIS
                )
        );

        center.setBorder(
                new EmptyBorder(
                        35, 50, 30, 50
                )
        );

        JLabel label =
                new JLabel(
                        "THỜI GIAN CÒN LẠI"
                );

        label.setAlignmentX(
                Component.CENTER_ALIGNMENT
        );

        label.setForeground(
                new Color(107, 100, 115)
        );

        label.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        14
                )
        );

        lblTime =
                new JLabel("10");

        lblTime.setAlignmentX(
                Component.CENTER_ALIGNMENT
        );

        lblTime.setForeground(
                TEAL
        );

        lblTime.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        100
                )
        );

        lblStatus =
                new JLabel(
                        "Sẵn sàng bắt đầu"
                );

        lblStatus.setAlignmentX(
                Component.CENTER_ALIGNMENT
        );

        lblStatus.setForeground(
                new Color(107, 100, 115)
        );

        lblStatus.setFont(
                new Font(
                        "Segoe UI",
                        Font.PLAIN,
                        14
                )
        );

        center.add(label);

        center.add(
                Box.createVerticalStrut(5)
        );

        center.add(lblTime);

        center.add(
                Box.createVerticalStrut(5)
        );

        center.add(lblStatus);

        center.add(
                Box.createVerticalStrut(30)
        );

        JPanel buttons =
                new JPanel(
                        new FlowLayout(
                                FlowLayout.CENTER,
                                12,
                                0
                        )
                );

        buttons.setOpaque(false);

        btnStart =
                createButton(
                        "▶  BẮT ĐẦU",
                        TEAL
                );

        btnReset =
                createButton(
                        "↻  ĐẶT LẠI",
                        PURPLE
                );

        buttons.add(btnStart);

        buttons.add(btnReset);

        center.add(buttons);

        main.add(
                header,
                BorderLayout.NORTH
        );

        main.add(
                center,
                BorderLayout.CENTER
        );

        add(main);

        btnStart.addActionListener(
                e -> startCountdown()
        );

        btnReset.addActionListener(
                e -> resetCountdown()
        );
    }

    private JButton createButton(
            String text,
            Color color
    ) {

        JButton button =
                new JButton(text);

        button.setForeground(
                Color.WHITE
        );

        button.setBackground(
                color
        );

        button.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        13
                )
        );

        button.setFocusPainted(false);

        button.setBorderPainted(false);

        button.setCursor(
                new Cursor(
                        Cursor.HAND_CURSOR
                )
        );

        button.setPreferredSize(
                new Dimension(
                        145,
                        45
                )
        );

        return button;
    }

    private void startCountdown() {

        btnStart.setEnabled(false);

        lblStatus.setText(
                "Đang đếm ngược..."
        );

        SwingWorker<Void, Integer> worker =
                new SwingWorker<>() {

                    @Override
                    protected Void doInBackground()
                            throws Exception {

                        for (
                                int i = seconds;
                                i >= 0;
                                i--
                        ) {

                            publish(i);

                            Thread.sleep(1000);
                        }

                        return null;
                    }

                    @Override
                    protected void process(
                            java.util.List<Integer> chunks
                    ) {

                        int value =
                                chunks.get(
                                        chunks.size() - 1
                                );

                        lblTime.setText(
                                String.valueOf(value)
                        );
                    }

                    @Override
                    protected void done() {

                        lblTime.setText("00");

                        lblStatus.setText(
                                "✓ Đếm ngược hoàn tất"
                        );

                        btnStart.setEnabled(true);

                        JOptionPane.showMessageDialog(
                                CountdownFrame.this,
                                "Đếm ngược đã hoàn thành!",
                                "Hoàn thành",
                                JOptionPane.INFORMATION_MESSAGE
                        );
                    }
                };

        worker.execute();
    }

    private void resetCountdown() {

        seconds = 10;

        lblTime.setText("10");

        lblStatus.setText(
                "Sẵn sàng bắt đầu"
        );

        btnStart.setEnabled(true);
    }
}