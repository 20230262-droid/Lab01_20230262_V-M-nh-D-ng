
package vn.edu.eaut.lab3;

public class Student {

    // ==============================
    // THUỘC TÍNH
    // ==============================

    private String maSinhVien;
    private String hoTen;
    private double diemTrungBinh;


    // ==============================
    // CONSTRUCTOR
    // ==============================

    public Student(String maSinhVien,
                   String hoTen,
                   double diemTrungBinh) {

        this.maSinhVien = maSinhVien;
        this.hoTen = hoTen;
        this.diemTrungBinh = diemTrungBinh;
    }


    // ==============================
    // GETTER - SETTER MÃ SINH VIÊN
    // ==============================

    public String getMaSinhVien() {
        return maSinhVien;
    }

    public void setMaSinhVien(String maSinhVien) {
        this.maSinhVien = maSinhVien;
    }


    // ==============================
    // GETTER - SETTER HỌ TÊN
    // ==============================

    public String getHoTen() {
        return hoTen;
    }

    public void setHoTen(String hoTen) {
        this.hoTen = hoTen;
    }


    // ==============================
    // GETTER - SETTER ĐIỂM TRUNG BÌNH
    // ==============================

    public double getDiemTrungBinh() {
        return diemTrungBinh;
    }

    public void setDiemTrungBinh(double diemTrungBinh) {
        this.diemTrungBinh = diemTrungBinh;
    }


    // ==============================
    // XẾP LOẠI SINH VIÊN
    // ==============================

    public String getXepLoai() {

        if (diemTrungBinh >= 8.5) {

            return "Giỏi";

        } else if (diemTrungBinh >= 7.0) {

            return "Khá";

        } else if (diemTrungBinh >= 5.0) {

            return "Trung bình";

        } else {

            return "Yếu";
        }
    }
}
