LAB 12 - SPRING MVC STUDENT

Chuc nang:
- Danh sach sinh vien
- Them
- Xem chi tiet
- Sua
- Xoa
- Tim kiem
- Validation
- Khong trung ma sinh vien
- Thymeleaf Form, ModelAttribute, BindingResult
- CRUD gia lap bang List trong bo nho

Chay:
1. Mo project bang IntelliJ IDEA.
2. Kiem tra Java/Maven:
   java -version
   javac -version
   mvn -version
3. Build:
   mvn clean package
4. Chay:
   mvn spring-boot:run
5. Truy cap:
   http://localhost:8080/students

Khong can cai Tomcat rieng.
Du lieu se mat khi dung ung dung.
