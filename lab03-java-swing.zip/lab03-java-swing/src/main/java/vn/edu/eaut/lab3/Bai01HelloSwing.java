package vn.edu.eaut.lab3;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class Bai01HelloSwing extends JFrame {

    private final JTextField txtName = new JTextField();

    private final Color BLUE = new Color(25, 118, 210);
    private final Color DARK_BLUE = new Color(13, 71, 161);
    private final Color BG = new Color(245, 248, 252);

    public Bai01HelloSwing() {

        setTitle("Bài 1 - Chào người dùng");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(520, 350);
        setLocationRelativeTo(null);
        setResizable(false);

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(BG);

        // HEADER
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(DARK_BLUE);
        header.setBorder(new EmptyBorder(25, 30, 25, 30));

        JLabel title = new JLabel("CHÀO NGƯỜI DÙNG");
        title.setFont(new Font("Arial", Font.BOLD, 26));
        title.setForeground(Color.WHITE);

        JLabel subtitle = new JLabel("Java Swing • Bài thực hành 01");
        subtitle.setFont(new Font("Arial", Font.PLAIN, 13));
        subtitle.setForeground(new Color(220, 235, 255));

        JPanel titleBox = new JPanel();
        titleBox.setOpaque(false);
        titleBox.setLayout(new BoxLayout(titleBox, BoxLayout.Y_AXIS));
        titleBox.add(title);
        titleBox.add(Box.createVerticalStrut(5));
        titleBox.add(subtitle);

        header.add(titleBox, BorderLayout.WEST);

        JLabel icon = new JLabel("👋");
        icon.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 40));
        header.add(icon, BorderLayout.EAST);

        mainPanel.add(header, BorderLayout.NORTH);

        // CARD
        JPanel card = new JPanel();
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(215, 225, 238)),
                new EmptyBorder(30, 35, 30, 35)
        ));
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));

        JLabel label = new JLabel("Nhập tên của bạn");
        label.setFont(new Font("Arial", Font.BOLD, 15));
        label.setForeground(new Color(45, 55, 70));

        txtName.setFont(new Font("Arial", Font.PLAIN, 15));
        txtName.setPreferredSize(new Dimension(400, 42));
        txtName.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));
        txtName.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(190, 205, 225)),
                new EmptyBorder(8, 12, 8, 12)
        ));

        JButton btnHello = new JButton("👋  HIỂN THỊ LỜI CHÀO");
        btnHello.setFont(new Font("Arial", Font.BOLD, 13));
        btnHello.setForeground(Color.WHITE);
        btnHello.setBackground(BLUE);
        btnHello.setFocusPainted(false);
        btnHello.setBorderPainted(false);
        btnHello.setPreferredSize(new Dimension(400, 45));
        btnHello.setMaximumSize(new Dimension(Integer.MAX_VALUE, 45));
        btnHello.setCursor(new Cursor(Cursor.HAND_CURSOR));

        btnHello.addActionListener(e -> hienThiLoiChao());

        card.add(label);
        card.add(Box.createVerticalStrut(10));
        card.add(txtName);
        card.add(Box.createVerticalStrut(20));
        card.add(btnHello);

        JPanel center = new JPanel(new GridBagLayout());
        center.setBackground(BG);
        center.setBorder(new EmptyBorder(25, 30, 25, 30));
        center.add(card);

        mainPanel.add(center, BorderLayout.CENTER);

        add(mainPanel);

        txtName.requestFocus();
    }

    private void hienThiLoiChao() {

        String name = txtName.getText().trim();

        if (name.isEmpty()) {

            JOptionPane.showMessageDialog(
                    this,
                    "Vui lòng nhập tên của bạn!",
                    "Thiếu thông tin",
                    JOptionPane.WARNING_MESSAGE
            );

            txtName.requestFocus();
            return;
        }

        JOptionPane.showMessageDialog(
                this,
                "Xin chào, " + name + "!",
                "Lời chào",
                JOptionPane.INFORMATION_MESSAGE
        );
    }

    public static void main(String[] args) {

        SwingUtilities.invokeLater(() ->
                new Bai01HelloSwing().setVisible(true)
        );
    }
}