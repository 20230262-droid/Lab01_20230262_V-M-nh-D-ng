package vn.edu.eaut.lab4;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.io.BufferedReader;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;

public class Bai07_KeywordSearchFrame extends JFrame {

    private File selectedFile;

    private JButton btnChoose;
    private JButton btnSearch;

    private JTextField txtKeyword;

    private JLabel lblFile;
    private JLabel lblResult;

    private JTextArea txtResult;

    private JProgressBar progressBar;

    private final Color PURPLE_DARK =
            new Color(46, 16, 73);

    private final Color PURPLE =
            new Color(88, 28, 135);

    private final Color TEAL =
            new Color(13, 148, 136);

    private final Color BG =
            new Color(245, 243, 249);

    public Bai07_KeywordSearchFrame() {

        setTitle("Bài 7 - Tìm kiếm từ khóa");

        setSize(850, 650);

        setLocationRelativeTo(null);

        setDefaultCloseOperation(
                JFrame.DISPOSE_ON_CLOSE
        );

        initUI();
    }

    private void initUI() {

        JPanel main =
                new JPanel(
                        new BorderLayout()
                );

        main.setBackground(BG);

        JPanel header =
                new JPanel(
                        new BorderLayout()
                );

        header.setBackground(PURPLE_DARK);

        header.setBorder(
                new EmptyBorder(
                        22, 30, 22, 30
                )
        );

        JLabel title =
                new JLabel(
                        "BÀI 7  •  KEYWORD SEARCH"
                );

        title.setForeground(Color.WHITE);

        title.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        23
                )
        );

        JLabel tag =
                new JLabel(
                        "TEXT FILE"
                );

        tag.setForeground(
                new Color(153, 246, 228)
        );

        tag.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        12
                )
        );

        header.add(
                title,
                BorderLayout.WEST
        );

        header.add(
                tag,
                BorderLayout.EAST
        );

        JPanel top =
                new JPanel();

        top.setOpaque(false);

        top.setLayout(
                new BoxLayout(
                        top,
                        BoxLayout.Y_AXIS
                )
        );

        top.setBorder(
                new EmptyBorder(
                        25, 35, 10, 35
                )
        );

        JPanel choose =
                new JPanel(
                        new FlowLayout(
                                FlowLayout.LEFT
                        )
                );

        choose.setOpaque(false);

        btnChoose =
                new JButton(
                        "CHỌN FILE"
                );

        btnSearch =
                new JButton(
                        "TÌM KIẾM"
                );

        styleButton(
                btnChoose,
                PURPLE
        );

        styleButton(
                btnSearch,
                TEAL
        );

        txtKeyword =
                new JTextField(18);

        txtKeyword.setFont(
                new Font(
                        "Segoe UI",
                        Font.PLAIN,
                        14
                )
        );

        choose.add(btnChoose);

        choose.add(
                new JLabel("Từ khóa:")
        );

        choose.add(txtKeyword);

        choose.add(btnSearch);

        lblFile =
                new JLabel(
                        "Chưa chọn file"
                );

        lblFile.setForeground(
                new Color(107, 100, 115)
        );

        top.add(choose);

        top.add(lblFile);

        // TEXT AREA

        txtResult =
                new JTextArea();

        txtResult.setFont(
                new Font(
                        "Consolas",
                        Font.PLAIN,
                        14
                )
        );

        txtResult.setLineWrap(true);

        txtResult.setWrapStyleWord(true);

        txtResult.setEditable(false);

        JScrollPane scroll =
                new JScrollPane(
                        txtResult
                );

        scroll.setBorder(
                BorderFactory.createTitledBorder(
                        "Các dòng tìm thấy"
                )
        );

        lblResult =
                new JLabel(
                        "Tìm thấy: 0 dòng"
                );

        lblResult.setForeground(PURPLE);

        lblResult.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        15
                )
        );

        progressBar =
                new JProgressBar(
                        0,
                        100
                );

        progressBar.setStringPainted(true);

        progressBar.setForeground(TEAL);

        JPanel bottom =
                new JPanel(
                        new BorderLayout(
                                10,
                                5
                        )
                );

        bottom.setBorder(
                new EmptyBorder(
                        10, 30, 15, 30
                )
        );

        bottom.setOpaque(false);

        bottom.add(
                lblResult,
                BorderLayout.WEST
        );

        bottom.add(
                progressBar,
                BorderLayout.CENTER
        );

        JPanel center =
                new JPanel(
                        new BorderLayout()
                );

        center.setOpaque(false);

        center.add(
                top,
                BorderLayout.NORTH
        );

        center.add(
                scroll,
                BorderLayout.CENTER
        );

        main.add(
                header,
                BorderLayout.NORTH
        );

        main.add(
                center,
                BorderLayout.CENTER
        );

        main.add(
                bottom,
                BorderLayout.SOUTH
        );

        add(main);

        btnChoose.addActionListener(
                e -> chooseFile()
        );

        btnSearch.addActionListener(
                e -> searchKeyword()
        );
    }

    private void styleButton(
            JButton button,
            Color color
    ) {

        button.setForeground(Color.WHITE);

        button.setBackground(color);

        button.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        13
                )
        );

        button.setFocusPainted(false);

        button.setBorderPainted(false);
    }

    private void chooseFile() {

        JFileChooser chooser =
                new JFileChooser();

        int result =
                chooser.showOpenDialog(this);

        if (
                result ==
                        JFileChooser.APPROVE_OPTION
        ) {

            selectedFile =
                    chooser.getSelectedFile();

            lblFile.setText(
                    "File: "
                            + selectedFile
                            .getAbsolutePath()
            );
        }
    }

    private void searchKeyword() {

        if (selectedFile == null) {

            JOptionPane.showMessageDialog(
                    this,
                    "Vui lòng chọn file",
                    "Thông báo",
                    JOptionPane.WARNING_MESSAGE
            );

            return;
        }

        String keyword =
                txtKeyword.getText().trim();

        if (keyword.isEmpty()) {

            JOptionPane.showMessageDialog(
                    this,
                    "Vui lòng nhập từ khóa",
                    "Thông báo",
                    JOptionPane.WARNING_MESSAGE
            );

            return;
        }

        btnSearch.setEnabled(false);

        txtResult.setText("");

        progressBar.setValue(0);

        SwingWorker<Integer, String> worker =
                new SwingWorker<>() {

                    @Override
                    protected Integer doInBackground()
                            throws Exception {

                        int found = 0;

                        int lineNumber = 0;

                        long total =
                                Files.size(
                                        selectedFile.toPath()
                                );

                        long read = 0;

                        try (
                                BufferedReader reader =
                                        Files.newBufferedReader(
                                                selectedFile.toPath(),
                                                StandardCharsets.UTF_8
                                        )
                        ) {

                            String line;

                            while (
                                    (line =
                                            reader.readLine())
                                            != null
                            ) {

                                lineNumber++;

                                read +=
                                        line.getBytes(
                                                StandardCharsets.UTF_8
                                        ).length + 1;

                                if (
                                        line.toLowerCase()
                                                .contains(
                                                        keyword
                                                                .toLowerCase()
                                                )
                                ) {

                                    found++;

                                    publish(
                                            "Dòng "
                                                    + lineNumber
                                                    + ": "
                                                    + line
                                    );
                                }

                                int progress =
                                        total == 0
                                                ? 100
                                                : (int)
                                                Math.min(
                                                        100,
                                                        read
                                                                * 100
                                                                / total
                                                );

                                setProgress(
                                        progress
                                );
                            }
                        }

                        return found;
                    }

                    @Override
                    protected void process(
                            java.util.List<String> chunks
                    ) {

                        for (
                                String line :
                                chunks
                        ) {

                            txtResult.append(
                                    line + "\n"
                            );
                        }
                    }

                    @Override
                    protected void done() {

                        try {

                            int count = get();

                            lblResult.setText(
                                    "Tìm thấy: "
                                            + count
                                            + " dòng"
                            );

                        } catch (Exception ex) {

                            lblResult.setText(
                                    "Lỗi khi tìm kiếm"
                            );
                        }

                        progressBar.setValue(100);

                        btnSearch.setEnabled(true);
                    }
                };

        worker.addPropertyChangeListener(
                evt -> {

                    if (
                            "progress".equals(
                                    evt.getPropertyName()
                            )
                    ) {

                        progressBar.setValue(
                                (int) evt.getNewValue()
                        );
                    }
                }
        );

        worker.execute();
    }
}