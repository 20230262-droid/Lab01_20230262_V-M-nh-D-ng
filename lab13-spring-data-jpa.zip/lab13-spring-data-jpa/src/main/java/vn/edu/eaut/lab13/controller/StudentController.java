package vn.edu.eaut.lab13.controller;
import jakarta.validation.Valid; import org.springframework.stereotype.Controller; import org.springframework.ui.Model; import org.springframework.validation.BindingResult; import org.springframework.web.bind.annotation.*; import vn.edu.eaut.lab13.entity.Student; import vn.edu.eaut.lab13.service.StudentService;
@Controller @RequestMapping("/students") public class StudentController { private final StudentService service; public StudentController(StudentService s){service=s;}
@GetMapping public String list(@RequestParam(required=false)String keyword,Model m){m.addAttribute("students",service.search(keyword));m.addAttribute("keyword",keyword);return "students/list";}
@GetMapping("/create") public String create(Model m){m.addAttribute("student",new Student());m.addAttribute("pageTitle","Thêm sinh viên");return "students/form";}
@GetMapping("/edit/{id}") public String edit(@PathVariable Long id,Model m){m.addAttribute("student",service.findById(id));m.addAttribute("pageTitle","Sửa sinh viên");return "students/form";}
@PostMapping("/save") public String save(@Valid @ModelAttribute("student")Student s,BindingResult r,Model m){if(service.existsCode(s.getStudentCode(),s.getId()))r.rejectValue("studentCode","duplicate","Mã sinh viên đã tồn tại");if(r.hasErrors()){m.addAttribute("pageTitle",s.getId()==null?"Thêm sinh viên":"Sửa sinh viên");return "students/form";}service.save(s);return "redirect:/students";}
@GetMapping("/delete/{id}") public String delete(@PathVariable Long id){service.deleteById(id);return "redirect:/students";}}
