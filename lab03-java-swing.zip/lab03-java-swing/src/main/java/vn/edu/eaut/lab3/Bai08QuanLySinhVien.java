
        package vn.edu.eaut.lab3;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class Bai08QuanLySinhVien extends JFrame {

    // ==============================
    // MÀU GIAO DIỆN
    // ==============================

    private static final Color BLUE =
            new Color(25, 118, 210);

    private static final Color DARK_BLUE =
            new Color(13, 71, 161);

    private static final Color LIGHT_BLUE =
            new Color(232, 242, 255);

    private static final Color WHITE =
            Color.WHITE;

    private static final Color TEXT =
            new Color(40, 40, 40);

    private static final Color BORDER =
            new Color(210, 220, 235);


    // ==============================
    // COMPONENT
    // ==============================

    private JTextField txtMaSV;
    private JTextField txtHoTen;
    private JTextField txtDiem;

    private JTable table;

    private DefaultTableModel tableModel;

    private JLabel lblSoLuong;


    // ==============================
    // CONSTRUCTOR
    // ==============================

    public Bai08QuanLySinhVien() {

        setTitle("Quản lý sinh viên - Bài 8");

        setDefaultCloseOperation(
                JFrame.EXIT_ON_CLOSE
        );

        setSize(950, 650);

        setLocationRelativeTo(null);

        setResizable(false);


        // ==============================
        // PANEL CHÍNH
        // ==============================

        JPanel mainPanel =
                new JPanel(new BorderLayout());

        mainPanel.setBackground(
                new Color(245, 248, 252)
        );


        // ==============================
        // HEADER
        // ==============================

        JPanel headerPanel =
                new JPanel(
                        new BorderLayout()
                );

        headerPanel.setBackground(
                DARK_BLUE
        );

        headerPanel.setBorder(
                new EmptyBorder(
                        20,
                        25,
                        20,
                        25
                )
        );


        JLabel lblTitle =
                new JLabel(
                        "QUẢN LÝ SINH VIÊN"
                );

        lblTitle.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        28
                )
        );

        lblTitle.setForeground(
                WHITE
        );


        JLabel lblSubTitle =
                new JLabel(
                        "QUẢN LÝ THÔNG TIN • ĐIỂM • XẾP LOẠI"
                );

        lblSubTitle.setFont(
                new Font(
                        "Arial",
                        Font.PLAIN,
                        13
                )
        );

        lblSubTitle.setForeground(
                new Color(220, 235, 255)
        );


        JPanel titlePanel =
                new JPanel();

        titlePanel.setLayout(
                new BoxLayout(
                        titlePanel,
                        BoxLayout.Y_AXIS
                )
        );

        titlePanel.setOpaque(false);

        titlePanel.add(lblTitle);

        titlePanel.add(
                Box.createVerticalStrut(5)
        );

        titlePanel.add(lblSubTitle);


        headerPanel.add(
                titlePanel,
                BorderLayout.WEST
        );


        JLabel lblIcon =
                new JLabel("🎓");

        lblIcon.setFont(
                new Font(
                        "Segoe UI Emoji",
                        Font.PLAIN,
                        42
                )
        );

        headerPanel.add(
                lblIcon,
                BorderLayout.EAST
        );


        mainPanel.add(
                headerPanel,
                BorderLayout.NORTH
        );


        // ==============================
        // CONTENT
        // ==============================

        JPanel contentPanel =
                new JPanel(
                        new BorderLayout(
                                15,
                                15
                        )
                );

        contentPanel.setBackground(
                new Color(245, 248, 252)
        );

        contentPanel.setBorder(
                new EmptyBorder(
                        18,
                        20,
                        18,
                        20
                )
        );


        // ==============================
        // FORM NHẬP THÔNG TIN
        // ==============================

        JPanel formPanel =
                new JPanel(
                        new GridBagLayout()
                );

        formPanel.setBackground(
                WHITE
        );

        formPanel.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(
                                BORDER
                        ),
                        new EmptyBorder(
                                15,
                                18,
                                15,
                                18
                        )
                )
        );


        GridBagConstraints gbc =
                new GridBagConstraints();

        gbc.insets =
                new Insets(
                        7,
                        7,
                        7,
                        7
                );

        gbc.fill =
                GridBagConstraints.HORIZONTAL;


        // Tiêu đề form

        JLabel lblFormTitle =
                new JLabel(
                        "THÔNG TIN SINH VIÊN"
                );

        lblFormTitle.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        17
                )
        );

        lblFormTitle.setForeground(
                DARK_BLUE
        );


        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;

        formPanel.add(
                lblFormTitle,
                gbc
        );


        // ==============================
        // MÃ SINH VIÊN
        // ==============================

        gbc.gridwidth = 1;

        gbc.gridx = 0;
        gbc.gridy = 1;

        JLabel lblMaSV =
                createLabel(
                        "Mã sinh viên"
                );

        formPanel.add(
                lblMaSV,
                gbc
        );


        txtMaSV =
                createTextField();

        gbc.gridx = 1;
        gbc.weightx = 1;

        formPanel.add(
                txtMaSV,
                gbc
        );


        // ==============================
        // HỌ TÊN
        // ==============================

        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.weightx = 0;

        JLabel lblHoTen =
                createLabel(
                        "Họ và tên"
                );

        formPanel.add(
                lblHoTen,
                gbc
        );


        txtHoTen =
                createTextField();

        gbc.gridx = 1;
        gbc.weightx = 1;

        formPanel.add(
                txtHoTen,
                gbc
        );


        // ==============================
        // ĐIỂM
        // ==============================

        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.weightx = 0;

        JLabel lblDiem =
                createLabel(
                        "Điểm trung bình"
                );

        formPanel.add(
                lblDiem,
                gbc
        );


        txtDiem =
                createTextField();

        gbc.gridx = 1;
        gbc.weightx = 1;

        formPanel.add(
                txtDiem,
                gbc
        );


        // ==============================
        // GỢI Ý
        // ==============================

        JLabel lblHint =
                new JLabel(
                        "Điểm hợp lệ: từ 0 đến 10"
                );

        lblHint.setFont(
                new Font(
                        "Arial",
                        Font.ITALIC,
                        11
                )
        );

        lblHint.setForeground(
                new Color(110, 120, 135)
        );


        gbc.gridx = 1;
        gbc.gridy = 4;

        formPanel.add(
                lblHint,
                gbc
        );


        // ==============================
        // BUTTON
        // ==============================

        JPanel buttonPanel =
                new JPanel(
                        new FlowLayout(
                                FlowLayout.CENTER,
                                10,
                                5
                        )
                );

        buttonPanel.setBackground(
                WHITE
        );


        JButton btnThem =
                createButton(
                        "＋  THÊM",
                        BLUE
                );

        JButton btnSua =
                createButton(
                        "✎  SỬA",
                        new Color(0, 150, 136)
                );

        JButton btnXoa =
                createButton(
                        "✕  XÓA",
                        new Color(211, 47, 47)
                );

        JButton btnLamMoi =
                createButton(
                        "↻  LÀM MỚI",
                        new Color(100, 116, 139)
                );


        buttonPanel.add(btnThem);

        buttonPanel.add(btnSua);

        buttonPanel.add(btnXoa);

        buttonPanel.add(btnLamMoi);


        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.gridwidth = 2;

        formPanel.add(
                buttonPanel,
                gbc
        );


        // ==============================
        // TABLE
        // ==============================

        String[] columns = {

                "Mã sinh viên",
                "Họ và tên",
                "Điểm TB",
                "Xếp loại"
        };


        tableModel =
                new DefaultTableModel(
                        columns,
                        0
                ) {

                    @Override
                    public boolean isCellEditable(
                            int row,
                            int column
                    ) {

                        return false;
                    }
                };


        table =
                new JTable(tableModel);


        // Chiều cao dòng

        table.setRowHeight(34);


        // Font

        table.setFont(
                new Font(
                        "Arial",
                        Font.PLAIN,
                        14
                )
        );


        // Màu nền

        table.setBackground(
                WHITE
        );

        table.setForeground(
                TEXT
        );


        // Grid

        table.setGridColor(
                new Color(
                        225,
                        230,
                        238
                )
        );


        // Chọn dòng

        table.setSelectionBackground(
                new Color(
                        210,
                        230,
                        255
                )
        );

        table.setSelectionForeground(
                DARK_BLUE
        );


        // ==============================
        // HEADER TABLE
        // ==============================

        table.getTableHeader()
                .setPreferredSize(
                        new Dimension(
                                0,
                                40
                        )
                );


        table.getTableHeader()
                .setFont(
                        new Font(
                                "Arial",
                                Font.BOLD,
                                14
                        )
                );


        table.getTableHeader()
                .setBackground(
                        DARK_BLUE
                );


        table.getTableHeader()
                .setForeground(
                        WHITE
                );


        // ==============================
        // CĂN GIỮA CỘT
        // ==============================

        DefaultTableCellRenderer centerRenderer =
                new DefaultTableCellRenderer();

        centerRenderer.setHorizontalAlignment(
                SwingConstants.CENTER
        );


        table.getColumnModel()
                .getColumn(0)
                .setCellRenderer(
                        centerRenderer
                );


        table.getColumnModel()
                .getColumn(2)
                .setCellRenderer(
                        centerRenderer
                );


        table.getColumnModel()
                .getColumn(3)
                .setCellRenderer(
                        centerRenderer
                );


        // ==============================
        // ĐỘ RỘNG CỘT
        // ==============================

        table.getColumnModel()
                .getColumn(0)
                .setPreferredWidth(130);

        table.getColumnModel()
                .getColumn(1)
                .setPreferredWidth(300);

        table.getColumnModel()
                .getColumn(2)
                .setPreferredWidth(120);

        table.getColumnModel()
                .getColumn(3)
                .setPreferredWidth(160);


        // ==============================
        // SCROLLPANE
        // ==============================

        JScrollPane scrollPane =
                new JScrollPane(
                        table
                );

        scrollPane.setBorder(
                BorderFactory.createLineBorder(
                        BORDER
                )
        );


        // ==============================
        // TIÊU ĐỀ DANH SÁCH
        // ==============================

        JPanel tableTitlePanel =
                new JPanel(
                        new BorderLayout()
                );

        tableTitlePanel.setBackground(
                WHITE
        );

        tableTitlePanel.setBorder(
                new EmptyBorder(
                        12,
                        5,
                        10,
                        5
                )
        );


        JLabel lblDanhSach =
                new JLabel(
                        "DANH SÁCH SINH VIÊN"
                );

        lblDanhSach.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        17
                )
        );

        lblDanhSach.setForeground(
                DARK_BLUE
        );


        lblSoLuong =
                new JLabel(
                        "Số lượng: 0"
                );

        lblSoLuong.setFont(
                new Font(
                        "Arial",
                        Font.PLAIN,
                        13
                )
        );

        lblSoLuong.setForeground(
                new Color(
                        100,
                        110,
                        125
                )
        );


        tableTitlePanel.add(
                lblDanhSach,
                BorderLayout.WEST
        );

        tableTitlePanel.add(
                lblSoLuong,
                BorderLayout.EAST
        );


        // ==============================
        // PANEL TABLE
        // ==============================

        JPanel tablePanel =
                new JPanel(
                        new BorderLayout()
                );

        tablePanel.setBackground(
                WHITE
        );

        tablePanel.setBorder(
                BorderFactory.createLineBorder(
                        BORDER
                )
        );


        tablePanel.add(
                tableTitlePanel,
                BorderLayout.NORTH
        );

        tablePanel.add(
                scrollPane,
                BorderLayout.CENTER
        );


        // ==============================
        // ADD VÀO CONTENT
        // ==============================

        contentPanel.add(
                formPanel,
                BorderLayout.NORTH
        );

        contentPanel.add(
                tablePanel,
                BorderLayout.CENTER
        );


        mainPanel.add(
                contentPanel,
                BorderLayout.CENTER
        );


        // ==============================
        // FOOTER
        // ==============================

        JLabel lblFooter =
                new JLabel(
                        "Java Swing • Student Management System",
                        SwingConstants.CENTER
                );

        lblFooter.setFont(
                new Font(
                        "Arial",
                        Font.PLAIN,
                        11
                )
        );

        lblFooter.setForeground(
                new Color(
                        130,
                        140,
                        155
                )
        );

        lblFooter.setBorder(
                new EmptyBorder(
                        0,
                        0,
                        8,
                        0
                )
        );


        mainPanel.add(
                lblFooter,
                BorderLayout.SOUTH
        );


        // ==============================
        // HIỂN THỊ
        // ==============================

        add(mainPanel);


        // ==============================
        // SỰ KIỆN THÊM
        // ==============================

        btnThem.addActionListener(
                e -> themSinhVien()
        );


        // ==============================
        // SỰ KIỆN SỬA
        // ==============================

        btnSua.addActionListener(
                e -> suaSinhVien()
        );


        // ==============================
        // SỰ KIỆN XÓA
        // ==============================

        btnXoa.addActionListener(
                e -> xoaSinhVien()
        );


        // ==============================
        // SỰ KIỆN LÀM MỚI
        // ==============================

        btnLamMoi.addActionListener(
                e -> lamMoi()
        );


        // ==============================
        // CLICK TABLE
        // ==============================

        table.getSelectionModel()
                .addListSelectionListener(
                        e -> hienThiSinhVien()
                );
    }


    // ==================================================
    // TẠO LABEL
    // ==================================================

    private JLabel createLabel(
            String text
    ) {

        JLabel label =
                new JLabel(text);

        label.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        13
                )
        );

        label.setForeground(
                TEXT
        );

        return label;
    }


    // ==================================================
    // TẠO TEXT FIELD
    // ==================================================

    private JTextField createTextField() {

        JTextField textField =
                new JTextField();

        textField.setFont(
                new Font(
                        "Arial",
                        Font.PLAIN,
                        14
                )
        );

        textField.setPreferredSize(
                new Dimension(
                        0,
                        36
                )
        );

        textField.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(
                                BORDER
                        ),
                        new EmptyBorder(
                                5,
                                10,
                                5,
                                10
                        )
                )
        );

        textField.setBackground(
                new Color(
                        250,
                        252,
                        255
                )
        );

        return textField;
    }


    // ==================================================
    // TẠO BUTTON
    // ==================================================

    private JButton createButton(
            String text,
            Color background
    ) {

        JButton button =
                new JButton(text);

        button.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        12
                )
        );

        button.setForeground(
                WHITE
        );

        button.setBackground(
                background
        );

        button.setPreferredSize(
                new Dimension(
                        125,
                        38
                )
        );

        button.setFocusPainted(
                false
        );

        button.setBorderPainted(
                false
        );

        button.setCursor(
                new Cursor(
                        Cursor.HAND_CURSOR
                )
        );

        return button;
    }


    // ==================================================
    // THÊM SINH VIÊN
    // ==================================================

    private void themSinhVien() {

        try {

            String maSV =
                    txtMaSV
                            .getText()
                            .trim();

            String hoTen =
                    txtHoTen
                            .getText()
                            .trim();

            String diemText =
                    txtDiem
                            .getText()
                            .trim();


            // Kiểm tra rỗng

            if (
                    maSV.isEmpty()
                            || hoTen.isEmpty()
                            || diemText.isEmpty()
            ) {

                JOptionPane.showMessageDialog(
                        this,
                        "Vui lòng nhập đầy đủ thông tin sinh viên!",
                        "Thiếu thông tin",
                        JOptionPane.WARNING_MESSAGE
                );

                return;
            }


            // Chuyển điểm

            double diem =
                    Double.parseDouble(
                            diemText
                    );


            // Kiểm tra điểm

            if (
                    diem < 0
                            || diem > 10
            ) {

                JOptionPane.showMessageDialog(
                        this,
                        "Điểm trung bình phải từ 0 đến 10!",
                        "Điểm không hợp lệ",
                        JOptionPane.ERROR_MESSAGE
                );

                txtDiem.requestFocus();

                return;
            }


            // Kiểm tra trùng mã

            for (
                    int i = 0;
                    i < tableModel.getRowCount();
                    i++
            ) {

                String maCu =
                        tableModel
                                .getValueAt(
                                        i,
                                        0
                                )
                                .toString();

                if (
                        maCu.equalsIgnoreCase(
                                maSV
                        )
                ) {

                    JOptionPane.showMessageDialog(
                            this,
                            "Mã sinh viên đã tồn tại!",
                            "Trùng mã sinh viên",
                            JOptionPane.WARNING_MESSAGE
                    );

                    txtMaSV.requestFocus();

                    return;
                }
            }


            // Tạo Student

            Student student =
                    new Student(
                            maSV,
                            hoTen,
                            diem
                    );


            // Thêm vào JTable

            tableModel.addRow(
                    new Object[]{

                            student.getMaSinhVien(),

                            student.getHoTen(),

                            student.getDiemTrungBinh(),

                            student.getXepLoai()
                    }
            );


            capNhatSoLuong();


            JOptionPane.showMessageDialog(
                    this,
                    "Đã thêm sinh viên thành công!",
                    "Thành công",
                    JOptionPane.INFORMATION_MESSAGE
            );


            lamMoi();

        } catch (
                NumberFormatException ex
        ) {

            JOptionPane.showMessageDialog(
                    this,
                    "Điểm trung bình phải là số!\nVí dụ: 8.5",
                    "Lỗi dữ liệu",
                    JOptionPane.ERROR_MESSAGE
            );

            txtDiem.requestFocus();
        }
    }


    // ==================================================
    // SỬA SINH VIÊN
    // ==================================================

    private void suaSinhVien() {

        int selectedRow =
                table.getSelectedRow();


        if (selectedRow == -1) {

            JOptionPane.showMessageDialog(
                    this,
                    "Vui lòng chọn một sinh viên trong bảng!",
                    "Chưa chọn sinh viên",
                    JOptionPane.WARNING_MESSAGE
            );

            return;
        }


        try {

            String maSV =
                    txtMaSV
                            .getText()
                            .trim();

            String hoTen =
                    txtHoTen
                            .getText()
                            .trim();

            String diemText =
                    txtDiem
                            .getText()
                            .trim();


            if (
                    maSV.isEmpty()
                            || hoTen.isEmpty()
                            || diemText.isEmpty()
            ) {

                JOptionPane.showMessageDialog(
                        this,
                        "Vui lòng nhập đầy đủ thông tin!",
                        "Thiếu thông tin",
                        JOptionPane.WARNING_MESSAGE
                );

                return;
            }


            double diem =
                    Double.parseDouble(
                            diemText
                    );


            if (
                    diem < 0
                            || diem > 10
            ) {

                JOptionPane.showMessageDialog(
                        this,
                        "Điểm phải nằm trong khoảng từ 0 đến 10!",
                        "Điểm không hợp lệ",
                        JOptionPane.ERROR_MESSAGE
                );

                return;
            }


            // Kiểm tra trùng mã
            // nhưng bỏ qua chính dòng đang sửa

            for (
                    int i = 0;
                    i < tableModel.getRowCount();
                    i++
            ) {

                if (i == selectedRow) {
                    continue;
                }

                String maCu =
                        tableModel
                                .getValueAt(
                                        i,
                                        0
                                )
                                .toString();

                if (
                        maCu.equalsIgnoreCase(
                                maSV
                        )
                ) {

                    JOptionPane.showMessageDialog(
                            this,
                            "Mã sinh viên đã tồn tại!",
                            "Trùng mã sinh viên",
                            JOptionPane.WARNING_MESSAGE
                    );

                    return;
                }
            }


            Student student =
                    new Student(
                            maSV,
                            hoTen,
                            diem
                    );


            // Cập nhật JTable

            tableModel.setValueAt(
                    student.getMaSinhVien(),
                    selectedRow,
                    0
            );

            tableModel.setValueAt(
                    student.getHoTen(),
                    selectedRow,
                    1
            );

            tableModel.setValueAt(
                    student.getDiemTrungBinh(),
                    selectedRow,
                    2
            );

            tableModel.setValueAt(
                    student.getXepLoai(),
                    selectedRow,
                    3
            );


            JOptionPane.showMessageDialog(
                    this,
                    "Đã cập nhật thông tin sinh viên!",
                    "Thành công",
                    JOptionPane.INFORMATION_MESSAGE
            );


            lamMoi();

        } catch (
                NumberFormatException ex
        ) {

            JOptionPane.showMessageDialog(
                    this,
                    "Điểm trung bình phải là số!",
                    "Lỗi dữ liệu",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }


    // ==================================================
    // XÓA SINH VIÊN
    // ==================================================

    private void xoaSinhVien() {

        int selectedRow =
                table.getSelectedRow();


        if (selectedRow == -1) {

            JOptionPane.showMessageDialog(
                    this,
                    "Vui lòng chọn sinh viên cần xóa!",
                    "Chưa chọn sinh viên",
                    JOptionPane.WARNING_MESSAGE
            );

            return;
        }


        String maSV =
                tableModel
                        .getValueAt(
                                selectedRow,
                                0
                        )
                        .toString();

        String hoTen =
                tableModel
                        .getValueAt(
                                selectedRow,
                                1
                        )
                        .toString();


        int confirm =
                JOptionPane.showConfirmDialog(
                        this,
                        "Bạn có chắc muốn xóa sinh viên?\n\n"
                                + "Mã SV: "
                                + maSV
                                + "\nHọ tên: "
                                + hoTen,
                        "Xác nhận xóa",
                        JOptionPane.YES_NO_OPTION,
                        JOptionPane.WARNING_MESSAGE
                );


        if (
                confirm ==
                        JOptionPane.YES_OPTION
        ) {

            tableModel.removeRow(
                    selectedRow
            );

            capNhatSoLuong();

            lamMoi();


            JOptionPane.showMessageDialog(
                    this,
                    "Đã xóa sinh viên!",
                    "Thành công",
                    JOptionPane.INFORMATION_MESSAGE
            );
        }
    }


    // ==================================================
    // HIỂN THỊ DỮ LIỆU KHI CLICK TABLE
    // ==================================================

    private void hienThiSinhVien() {

        int selectedRow =
                table.getSelectedRow();


        if (selectedRow == -1) {

            return;
        }


        txtMaSV.setText(
                tableModel
                        .getValueAt(
                                selectedRow,
                                0
                        )
                        .toString()
        );


        txtHoTen.setText(
                tableModel
                        .getValueAt(
                                selectedRow,
                                1
                        )
                        .toString()
        );


        txtDiem.setText(
                tableModel
                        .getValueAt(
                                selectedRow,
                                2
                        )
                        .toString()
        );
    }


    // ==================================================
    // LÀM MỚI FORM
    // ==================================================

    private void lamMoi() {

        txtMaSV.setText("");

        txtHoTen.setText("");

        txtDiem.setText("");

        table.clearSelection();

        txtMaSV.requestFocus();
    }


    // ==================================================
    // CẬP NHẬT SỐ LƯỢNG SINH VIÊN
    // ==================================================

    private void capNhatSoLuong() {

        int soLuong =
                tableModel.getRowCount();

        lblSoLuong.setText(
                "Số lượng: "
                        + soLuong
        );
    }


    // ==================================================
    // MAIN
    // ==================================================

    public static void main(
            String[] args
    ) {

        SwingUtilities.invokeLater(
                () -> {

                    try {

                        UIManager.setLookAndFeel(
                                UIManager
                                        .getSystemLookAndFeelClassName()
                        );

                    } catch (
                            Exception ignored
                    ) {
                    }


                    new Bai08QuanLySinhVien()
                            .setVisible(true);
                }
        );
    }
}

