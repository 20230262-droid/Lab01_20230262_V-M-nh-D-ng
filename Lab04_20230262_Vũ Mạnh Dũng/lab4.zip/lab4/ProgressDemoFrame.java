package vn.edu.eaut.lab4;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class ProgressDemoFrame extends JFrame {

    private JProgressBar progressBar;

    private JLabel lblPercent;
    private JLabel lblStatus;

    private JButton btnStart;

    private final Color PURPLE =
            new Color(88, 28, 135);

    private final Color TEAL =
            new Color(13, 148, 136);

    private final Color DARK =
            new Color(46, 16, 73);

    private final Color BG =
            new Color(245, 243, 249);

    public ProgressDemoFrame() {

        setTitle(
                "Progress Demo - SwingWorker"
        );

        setSize(680, 480);

        setLocationRelativeTo(null);

        setDefaultCloseOperation(
                JFrame.DISPOSE_ON_CLOSE
        );

        initUI();
    }

    private void initUI() {

        JPanel main =
                new JPanel(
                        new BorderLayout()
                );

        main.setBackground(BG);

        // HEADER

        JPanel header =
                new JPanel(
                        new BorderLayout()
                );

        header.setBackground(DARK);

        header.setBorder(
                new EmptyBorder(
                        22, 30, 22, 30
                )
        );

        JLabel title =
                new JLabel(
                        "PROGRESS TASK"
                );

        title.setForeground(
                Color.WHITE
        );

        title.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        25
                )
        );

        JLabel tag =
                new JLabel(
                        "BACKGROUND PROCESS"
                );

        tag.setForeground(
                new Color(196, 181, 253)
        );

        tag.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        12
                )
        );

        header.add(
                title,
                BorderLayout.WEST
        );

        header.add(
                tag,
                BorderLayout.EAST
        );

        // CONTENT

        JPanel center =
                new JPanel();

        center.setOpaque(false);

        center.setLayout(
                new BoxLayout(
                        center,
                        BoxLayout.Y_AXIS
                )
        );

        center.setBorder(
                new EmptyBorder(
                        40, 60, 35, 60
                )
        );

        JLabel titleText =
                new JLabel(
                        "TIẾN TRÌNH XỬ LÝ"
                );

        titleText.setAlignmentX(
                Component.CENTER_ALIGNMENT
        );

        titleText.setForeground(
                DARK
        );

        titleText.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        26
                )
        );

        JLabel description =
                new JLabel(
                        "Mô phỏng tác vụ chạy nền bằng SwingWorker"
                );

        description.setAlignmentX(
                Component.CENTER_ALIGNMENT
        );

        description.setForeground(
                new Color(107, 100, 115)
        );

        description.setFont(
                new Font(
                        "Segoe UI",
                        Font.PLAIN,
                        14
                )
        );

        progressBar =
                new JProgressBar(
                        0,
                        100
                );

        progressBar.setPreferredSize(
                new Dimension(
                        520,
                        20
                )
        );

        progressBar.setMaximumSize(
                new Dimension(
                        Integer.MAX_VALUE,
                        20
                )
        );

        progressBar.setForeground(
                TEAL
        );

        progressBar.setBackground(
                new Color(226, 232, 240)
        );

        progressBar.setBorderPainted(false);

        lblPercent =
                new JLabel("0%");

        lblPercent.setAlignmentX(
                Component.CENTER_ALIGNMENT
        );

        lblPercent.setForeground(
                TEAL
        );

        lblPercent.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        35
                )
        );

        lblStatus =
                new JLabel(
                        "Sẵn sàng xử lý"
                );

        lblStatus.setAlignmentX(
                Component.CENTER_ALIGNMENT
        );

        lblStatus.setForeground(
                new Color(107, 100, 115)
        );

        lblStatus.setFont(
                new Font(
                        "Segoe UI",
                        Font.PLAIN,
                        14
                )
        );

        btnStart =
                new JButton(
                        "▶  BẮT ĐẦU XỬ LÝ"
                );

        btnStart.setAlignmentX(
                Component.CENTER_ALIGNMENT
        );

        btnStart.setForeground(
                Color.WHITE
        );

        btnStart.setBackground(
                PURPLE
        );

        btnStart.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        14
                )
        );

        btnStart.setFocusPainted(false);

        btnStart.setBorderPainted(false);

        btnStart.setCursor(
                new Cursor(
                        Cursor.HAND_CURSOR
                )
        );

        btnStart.setPreferredSize(
                new Dimension(
                        210,
                        48
                )
        );

        btnStart.setMaximumSize(
                new Dimension(
                        210,
                        48
                )
        );

        center.add(titleText);

        center.add(
                Box.createVerticalStrut(7)
        );

        center.add(description);

        center.add(
                Box.createVerticalStrut(45)
        );

        center.add(progressBar);

        center.add(
                Box.createVerticalStrut(18)
        );

        center.add(lblPercent);

        center.add(
                Box.createVerticalStrut(5)
        );

        center.add(lblStatus);

        center.add(
                Box.createVerticalStrut(28)
        );

        center.add(btnStart);

        main.add(
                header,
                BorderLayout.NORTH
        );

        main.add(
                center,
                BorderLayout.CENTER
        );

        add(main);

        btnStart.addActionListener(
                e -> startProcess()
        );
    }

    private void startProcess() {

        btnStart.setEnabled(false);

        progressBar.setValue(0);

        lblPercent.setText("0%");

        lblStatus.setText(
                "Đang xử lý dữ liệu..."
        );

        SwingWorker<Integer, Integer> worker =
                new SwingWorker<>() {

                    @Override
                    protected Integer doInBackground()
                            throws Exception {

                        for (
                                int i = 0;
                                i <= 100;
                                i++
                        ) {

                            Thread.sleep(40);

                            publish(i);
                        }

                        return 100;
                    }

                    @Override
                    protected void process(
                            java.util.List<Integer> chunks
                    ) {

                        int value =
                                chunks.get(
                                        chunks.size() - 1
                                );

                        progressBar.setValue(value);

                        lblPercent.setText(
                                value + "%"
                        );

                        lblStatus.setText(
                                "Đang xử lý... "
                                        + value
                                        + "%"
                        );
                    }

                    @Override
                    protected void done() {

                        progressBar.setValue(100);

                        lblPercent.setText(
                                "100%"
                        );

                        lblStatus.setText(
                                "✓ Xử lý hoàn tất"
                        );

                        btnStart.setEnabled(true);

                        JOptionPane.showMessageDialog(
                                ProgressDemoFrame.this,
                                "Quá trình xử lý đã hoàn thành!",
                                "Hoàn thành",
                                JOptionPane.INFORMATION_MESSAGE
                        );
                    }
                };

        worker.execute();
    }
}