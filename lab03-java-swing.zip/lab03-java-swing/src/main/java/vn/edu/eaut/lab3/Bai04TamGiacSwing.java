package vn.edu.eaut.lab3;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.Arrays;

public class Bai04TamGiacSwing extends JFrame {

    private final JTextField txtA = new JTextField();
    private final JTextField txtB = new JTextField();
    private final JTextField txtC = new JTextField();

    private final JLabel lblResult =
            new JLabel("Kết quả: —");

    private final Color BLUE =
            new Color(25, 118, 210);

    private final Color DARK_BLUE =
            new Color(13, 71, 161);

    private final Color BG =
            new Color(245, 248, 252);

    public Bai04TamGiacSwing() {

        setTitle("Bài 4 - Kiểm tra và phân loại tam giác");

        setDefaultCloseOperation(
                JFrame.EXIT_ON_CLOSE
        );

        setSize(650, 570);

        setLocationRelativeTo(null);

        setResizable(false);


        JPanel main =
                new JPanel(
                        new BorderLayout()
                );

        main.setBackground(BG);


        // HEADER

        JPanel header =
                new JPanel(
                        new BorderLayout()
                );

        header.setBackground(DARK_BLUE);

        header.setBorder(
                new EmptyBorder(
                        22,
                        28,
                        22,
                        28
                )
        );


        JLabel title =
                new JLabel(
                        "KIỂM TRA & PHÂN LOẠI TAM GIÁC"
                );

        title.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        24
                )
        );

        title.setForeground(Color.WHITE);


        JLabel subtitle =
                new JLabel(
                        "Nhập ba cạnh a, b, c"
                );

        subtitle.setFont(
                new Font(
                        "Arial",
                        Font.PLAIN,
                        13
                )
        );

        subtitle.setForeground(
                new Color(
                        220,
                        235,
                        255
                )
        );


        JPanel titleBox =
                new JPanel();

        titleBox.setOpaque(false);

        titleBox.setLayout(
                new BoxLayout(
                        titleBox,
                        BoxLayout.Y_AXIS
                )
        );

        titleBox.add(title);

        titleBox.add(
                Box.createVerticalStrut(5)
        );

        titleBox.add(subtitle);


        header.add(
                titleBox,
                BorderLayout.WEST
        );


        JLabel icon =
                new JLabel("△");

        icon.setFont(
                new Font(
                        "Serif",
                        Font.BOLD,
                        42
                )
        );

        icon.setForeground(Color.WHITE);

        header.add(
                icon,
                BorderLayout.EAST
        );


        main.add(
                header,
                BorderLayout.NORTH
        );


        // CARD

        JPanel card =
                new JPanel(
                        new GridBagLayout()
                );

        card.setBackground(Color.WHITE);

        card.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(
                                new Color(
                                        215,
                                        225,
                                        238
                                )
                        ),
                        new EmptyBorder(
                                25,
                                30,
                                25,
                                30
                        )
                )
        );


        GridBagConstraints gbc =
                new GridBagConstraints();

        gbc.insets =
                new Insets(
                        8,
                        8,
                        8,
                        8
                );

        gbc.fill =
                GridBagConstraints.HORIZONTAL;


        JLabel la =
                createLabel("Cạnh a");

        JLabel lb =
                createLabel("Cạnh b");

        JLabel lc =
                createLabel("Cạnh c");


        styleField(txtA);
        styleField(txtB);
        styleField(txtC);


        gbc.gridx = 0;
        gbc.gridy = 0;

        card.add(
                la,
                gbc
        );


        gbc.gridx = 1;
        gbc.weightx = 1;

        card.add(
                txtA,
                gbc
        );


        gbc.gridx = 0;
        gbc.gridy = 1;

        gbc.weightx = 0;

        card.add(
                lb,
                gbc
        );


        gbc.gridx = 1;

        gbc.weightx = 1;

        card.add(
                txtB,
                gbc
        );


        gbc.gridx = 0;
        gbc.gridy = 2;

        gbc.weightx = 0;

        card.add(
                lc,
                gbc
        );


        gbc.gridx = 1;

        gbc.weightx = 1;

        card.add(
                txtC,
                gbc
        );


        JButton btnCheck =
                createButton(
                        "✓  KIỂM TRA",
                        BLUE
                );


        JButton btnClear =
                createButton(
                        "↻  LÀM MỚI",
                        new Color(
                                100,
                                116,
                                139
                        )
                );


        JPanel buttons =
                new JPanel(
                        new FlowLayout(
                                FlowLayout.CENTER,
                                10,
                                5
                        )
                );

        buttons.setOpaque(false);

        buttons.add(btnCheck);
        buttons.add(btnClear);


        gbc.gridx = 0;
        gbc.gridy = 3;

        gbc.gridwidth = 2;

        card.add(
                buttons,
                gbc
        );


        lblResult.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        17
                )
        );

        lblResult.setForeground(
                DARK_BLUE
        );

        lblResult.setHorizontalAlignment(
                SwingConstants.CENTER
        );


        gbc.gridy = 4;

        card.add(
                lblResult,
                gbc
        );


        JPanel center =
                new JPanel(
                        new GridBagLayout()
                );

        center.setBackground(BG);

        center.setBorder(
                new EmptyBorder(
                        25,
                        30,
                        25,
                        30
                )
        );

        center.add(card);


        main.add(
                center,
                BorderLayout.CENTER
        );


        add(main);


        btnCheck.addActionListener(
                e -> kiemTraTamGiac()
        );


        btnClear.addActionListener(
                e -> lamMoi()
        );
    }


    private JLabel createLabel(
            String text
    ) {

        JLabel label =
                new JLabel(text);

        label.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        14
                )
        );

        label.setForeground(
                new Color(
                        45,
                        55,
                        70
                )
        );

        return label;
    }


    private void styleField(
            JTextField field
    ) {

        field.setFont(
                new Font(
                        "Arial",
                        Font.PLAIN,
                        15
                )
        );

        field.setPreferredSize(
                new Dimension(
                        320,
                        40
                )
        );

        field.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(
                                new Color(
                                        190,
                                        205,
                                        225
                                )
                        ),
                        new EmptyBorder(
                                8,
                                12,
                                8,
                                12
                        )
                )
        );
    }


    private JButton createButton(
            String text,
            Color color
    ) {

        JButton button =
                new JButton(text);

        button.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        12
                )
        );

        button.setForeground(Color.WHITE);

        button.setBackground(color);

        button.setPreferredSize(
                new Dimension(
                        150,
                        42
                )
        );

        button.setFocusPainted(false);

        button.setBorderPainted(false);

        button.setCursor(
                new Cursor(
                        Cursor.HAND_CURSOR
                )
        );

        return button;
    }


    private void kiemTraTamGiac() {

        try {

            double a =
                    Double.parseDouble(
                            txtA.getText().trim()
                    );

            double b =
                    Double.parseDouble(
                            txtB.getText().trim()
                    );

            double c =
                    Double.parseDouble(
                            txtC.getText().trim()
                    );


            lblResult.setText(
                    "Kết quả: "
                            + loaiTamGiac(
                            a,
                            b,
                            c
                    )
            );

        } catch (
                NumberFormatException ex
        ) {

            JOptionPane.showMessageDialog(
                    this,
                    "Ba cạnh phải là số hợp lệ!",
                    "Lỗi dữ liệu",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }


    private String loaiTamGiac(
            double a,
            double b,
            double c
    ) {

        final double EPS =
                1e-9;


        if (
                a <= 0
                        || b <= 0
                        || c <= 0
                        || a + b <= c
                        || a + c <= b
                        || b + c <= a
        ) {

            return "Không phải tam giác";
        }


        boolean deu =
                Math.abs(a - b) < EPS
                        && Math.abs(b - c) < EPS;


        boolean can =
                Math.abs(a - b) < EPS
                        || Math.abs(a - c) < EPS
                        || Math.abs(b - c) < EPS;


        double[] d = {
                a,
                b,
                c
        };


        Arrays.sort(d);


        boolean vuong =
                Math.abs(
                        d[0] * d[0]
                                + d[1] * d[1]
                                - d[2] * d[2]
                ) < EPS;


        if (deu)
            return "Tam giác đều";

        if (vuong && can)
            return "Tam giác vuông cân";

        if (vuong)
            return "Tam giác vuông";

        if (can)
            return "Tam giác cân";

        return "Tam giác thường";
    }


    private void lamMoi() {

        txtA.setText("");
        txtB.setText("");
        txtC.setText("");

        lblResult.setText(
                "Kết quả: —"
        );

        txtA.requestFocus();
    }


    public static void main(
            String[] args
    ) {

        SwingUtilities.invokeLater(
                () ->
                        new Bai04TamGiacSwing()
                                .setVisible(true)
        );
    }
}