package vn.edu.eaut.lab15.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import vn.edu.eaut.lab15.service.CourseService;
import vn.edu.eaut.lab15.service.EnrollmentService;
import vn.edu.eaut.lab15.service.StudentService;

@Controller
@RequestMapping("/enrollments")
public class EnrollmentController {
    private final EnrollmentService enrollmentService;
    private final StudentService studentService;
    private final CourseService courseService;

    public EnrollmentController(EnrollmentService enrollmentService,
                                StudentService studentService,
                                CourseService courseService) {
        this.enrollmentService = enrollmentService;
        this.studentService = studentService;
        this.courseService = courseService;
    }

    @GetMapping
    public String list(Model model) {
        model.addAttribute("enrollments", enrollmentService.findAll());
        return "enrollments/list";
    }

    @GetMapping("/create")
    public String create(Model model) {
        model.addAttribute("students", studentService.findAll());
        model.addAttribute("courses", courseService.findAll());
        return "enrollments/form";
    }

    @PostMapping("/save")
    public String save(@RequestParam Long studentId,
                       @RequestParam Long courseId,
                       Model model) {
        try {
            enrollmentService.enroll(studentId, courseId);
            return "redirect:/enrollments?success=1";
        } catch (RuntimeException e) {
            model.addAttribute("error", e.getMessage());
            model.addAttribute("students", studentService.findAll());
            model.addAttribute("courses", courseService.findAll());
            return "enrollments/form";
        }
    }

    @GetMapping("/delete/{id}")
    public String delete(@PathVariable Long id) {
        enrollmentService.delete(id);
        return "redirect:/enrollments?deleted=1";
    }

    @GetMapping("/student/{studentId}")
    public String byStudent(@PathVariable Long studentId, Model model) {
        model.addAttribute("student", studentService.findById(studentId));
        model.addAttribute("enrollments", enrollmentService.findByStudent(studentId));
        return "enrollments/student";
    }
}
