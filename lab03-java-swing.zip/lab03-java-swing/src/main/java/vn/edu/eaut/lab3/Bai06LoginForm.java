package vn.edu.eaut.lab3;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class Bai06LoginForm extends JFrame {

    private final JTextField txtUsername =
            new JTextField();

    private final JPasswordField txtPassword =
            new JPasswordField();

    private final JComboBox<String> cboRole =
            new JComboBox<>(
                    new String[]{
                            "Admin",
                            "User"
                    }
            );

    private final JCheckBox chkShowPassword =
            new JCheckBox(
                    "Hiển thị mật khẩu"
            );

    private final Color BLUE =
            new Color(25, 118, 210);

    private final Color DARK_BLUE =
            new Color(13, 71, 161);

    private final Color BG =
            new Color(245, 248, 252);

    public Bai06LoginForm() {

        setTitle(
                "Bài 6 - Đăng nhập hệ thống"
        );

        setDefaultCloseOperation(
                JFrame.EXIT_ON_CLOSE
        );

        setSize(
                560,
                620
        );

        setLocationRelativeTo(null);

        setResizable(false);


        JPanel main =
                new JPanel(
                        new BorderLayout()
                );

        main.setBackground(BG);


        // HEADER

        JPanel header =
                new JPanel(
                        new BorderLayout()
                );

        header.setBackground(
                DARK_BLUE
        );

        header.setBorder(
                new EmptyBorder(
                        25,
                        30,
                        25,
                        30
                )
        );


        JLabel title =
                new JLabel(
                        "ĐĂNG NHẬP HỆ THỐNG"
                );

        title.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        26
                )
        );

        title.setForeground(
                Color.WHITE
        );


        JLabel subtitle =
                new JLabel(
                        "Java Swing • Authentication"
                );

        subtitle.setFont(
                new Font(
                        "Arial",
                        Font.PLAIN,
                        13
                )
        );

        subtitle.setForeground(
                new Color(
                        220,
                        235,
                        255
                )
        );


        JPanel titleBox =
                new JPanel();

        titleBox.setOpaque(false);

        titleBox.setLayout(
                new BoxLayout(
                        titleBox,
                        BoxLayout.Y_AXIS
                )
        );

        titleBox.add(title);

        titleBox.add(
                Box.createVerticalStrut(5)
        );

        titleBox.add(subtitle);


        header.add(
                titleBox,
                BorderLayout.WEST
        );


        JLabel icon =
                new JLabel("🔐");

        icon.setFont(
                new Font(
                        "Segoe UI Emoji",
                        Font.PLAIN,
                        42
                )
        );

        header.add(
                icon,
                BorderLayout.EAST
        );


        main.add(
                header,
                BorderLayout.NORTH
        );


        // LOGIN CARD

        JPanel card =
                new JPanel(
                        new GridBagLayout()
                );

        card.setBackground(
                Color.WHITE
        );

        card.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(
                                new Color(
                                        215,
                                        225,
                                        238
                                )
                        ),
                        new EmptyBorder(
                                30,
                                35,
                                30,
                                35
                        )
                )
        );


        GridBagConstraints gbc =
                new GridBagConstraints();

        gbc.insets =
                new Insets(
                        7,
                        7,
                        7,
                        7
                );

        gbc.fill =
                GridBagConstraints.HORIZONTAL;


        JLabel lblAccount =
                createLabel(
                        "Tên tài khoản"
                );


        styleField(
                txtUsername
        );


        gbc.gridx = 0;
        gbc.gridy = 0;

        card.add(
                lblAccount,
                gbc
        );


        gbc.gridx = 1;
        gbc.weightx = 1;

        card.add(
                txtUsername,
                gbc
        );


        JLabel lblPassword =
                createLabel(
                        "Mật khẩu"
                );


        styleField(
                txtPassword
        );


        gbc.gridx = 0;
        gbc.gridy = 1;

        gbc.weightx = 0;

        card.add(
                lblPassword,
                gbc
        );


        gbc.gridx = 1;

        gbc.weightx = 1;

        card.add(
                txtPassword,
                gbc
        );


        JLabel lblRole =
                createLabel(
                        "Vai trò"
                );


        cboRole.setFont(
                new Font(
                        "Arial",
                        Font.PLAIN,
                        14
                )
        );

        cboRole.setPreferredSize(
                new Dimension(
                        280,
                        40
                )
        );


        gbc.gridx = 0;
        gbc.gridy = 2;

        gbc.weightx = 0;

        card.add(
                lblRole,
                gbc
        );


        gbc.gridx = 1;

        gbc.weightx = 1;

        card.add(
                cboRole,
                gbc
        );


        chkShowPassword.setBackground(
                Color.WHITE
        );

        chkShowPassword.setFont(
                new Font(
                        "Arial",
                        Font.PLAIN,
                        12
                )
        );


        gbc.gridx = 1;
        gbc.gridy = 3;

        card.add(
                chkShowPassword,
                gbc
        );


        JButton btnLogin =
                new JButton(
                        "🔑  ĐĂNG NHẬP"
                );

        btnLogin.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        13
                )
        );

        btnLogin.setForeground(
                Color.WHITE
        );

        btnLogin.setBackground(
                BLUE
        );

        btnLogin.setPreferredSize(
                new Dimension(
                        300,
                        45
                )
        );

        btnLogin.setFocusPainted(false);

        btnLogin.setBorderPainted(false);

        btnLogin.setCursor(
                new Cursor(
                        Cursor.HAND_CURSOR
                )
        );


        gbc.gridx = 0;
        gbc.gridy = 4;

        gbc.gridwidth = 2;

        card.add(
                btnLogin,
                gbc
        );


        JLabel hint =
                new JLabel(
                        "<html><center>"
                                + "Tài khoản mẫu:<br>"
                                + "<b>admin / 123456</b> hoặc "
                                + "<b>user / 123456</b>"
                                + "</center></html>"
                );

        hint.setHorizontalAlignment(
                SwingConstants.CENTER
        );

        hint.setFont(
                new Font(
                        "Arial",
                        Font.PLAIN,
                        12
                )
        );

        hint.setForeground(
                new Color(
                        100,
                        110,
                        125
                )
        );


        gbc.gridy = 5;

        card.add(
                hint,
                gbc
        );


        JPanel center =
                new JPanel(
                        new GridBagLayout()
                );

        center.setBackground(BG);

        center.setBorder(
                new EmptyBorder(
                        25,
                        30,
                        25,
                        30
                )
        );

        center.add(card);


        main.add(
                center,
                BorderLayout.CENTER
        );


        add(main);


        // SHOW PASSWORD

        chkShowPassword.addActionListener(
                e -> {

                    if (
                            chkShowPassword.isSelected()
                    ) {

                        txtPassword.setEchoChar(
                                (char) 0
                        );

                    } else {

                        txtPassword.setEchoChar(
                                '•'
                        );
                    }
                }
        );


        // LOGIN

        btnLogin.addActionListener(
                e -> dangNhap()
        );


        txtUsername.requestFocus();
    }


    private JLabel createLabel(
            String text
    ) {

        JLabel label =
                new JLabel(text);

        label.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        13
                )
        );

        label.setForeground(
                new Color(
                        45,
                        55,
                        70
                )
        );

        return label;
    }


    private void styleField(
            JTextField field
    ) {

        field.setFont(
                new Font(
                        "Arial",
                        Font.PLAIN,
                        14
                )
        );

        field.setPreferredSize(
                new Dimension(
                        280,
                        40
                )
        );

        field.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(
                                new Color(
                                        190,
                                        205,
                                        225
                                )
                        ),
                        new EmptyBorder(
                                8,
                                10,
                                8,
                                10
                        )
                )
        );
    }


    private void dangNhap() {

        String username =
                txtUsername
                        .getText()
                        .trim();

        String password =
                new String(
                        txtPassword
                                .getPassword()
                );

        String role =
                cboRole
                        .getSelectedItem()
                        .toString();


        if (
                username.isEmpty()
                        || password.isEmpty()
        ) {

            JOptionPane.showMessageDialog(
                    this,
                    "Vui lòng nhập đầy đủ tài khoản và mật khẩu!",
                    "Thiếu thông tin",
                    JOptionPane.WARNING_MESSAGE
            );

            return;
        }


        boolean validAdmin =
                username.equals("admin")
                        && password.equals("123456")
                        && role.equals("Admin");


        boolean validUser =
                username.equals("user")
                        && password.equals("123456")
                        && role.equals("User");


        if (
                validAdmin
                        || validUser
        ) {

            JOptionPane.showMessageDialog(
                    this,
                    "Đăng nhập thành công!\n\n"
                            + "Xin chào "
                            + username
                            + "!\n"
                            + "Vai trò: "
                            + role,
                    "Đăng nhập thành công",
                    JOptionPane.INFORMATION_MESSAGE
            );

        } else {

            JOptionPane.showMessageDialog(
                    this,
                    "Tài khoản, mật khẩu hoặc vai trò không chính xác!",
                    "Đăng nhập thất bại",
                    JOptionPane.ERROR_MESSAGE
            );

            txtPassword.setText("");
            txtPassword.requestFocus();
        }
    }


    public static void main(
            String[] args
    ) {

        SwingUtilities.invokeLater(
                () ->
                        new Bai06LoginForm()
                                .setVisible(true)
        );
    }
}