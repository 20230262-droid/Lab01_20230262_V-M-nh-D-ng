package vn.edu.eaut.lab4;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/**
 * Giao diện dùng chung cho toàn bộ Lab 4
 * Tông màu: Pink Pastel
 */
public class UIStyle {

    // ==============================
    // MÀU CHỦ ĐẠO
    // ==============================

    // Hồng pastel
    public static final Color PINK = new Color(244, 143, 177);

    // Hồng đậm hơn khi hover
    public static final Color PINK_HOVER = new Color(236, 112, 154);

    // Hồng nhạt
    public static final Color PINK_LIGHT = new Color(255, 228, 236);

    // Nền chính
    public static final Color BACKGROUND = new Color(255, 247, 250);

    // Trắng
    public static final Color WHITE = new Color(255, 255, 255);

    // Chữ chính
    public static final Color TEXT = new Color(75, 55, 65);

    // Chữ phụ
    public static final Color TEXT_LIGHT = new Color(120, 95, 108);

    // Viền
    public static final Color BORDER = new Color(238, 190, 205);

    // Thành công
    public static final Color SUCCESS = new Color(102, 187, 106);

    // Đỏ
    public static final Color DANGER = new Color(239, 108, 108);

    // ==============================
    // FONT
    // ==============================

    public static final Font TITLE_FONT =
            new Font("Segoe UI", Font.BOLD, 25);

    public static final Font SUBTITLE_FONT =
            new Font("Segoe UI", Font.PLAIN, 14);

    public static final Font LABEL_FONT =
            new Font("Segoe UI", Font.BOLD, 14);

    public static final Font NORMAL_FONT =
            new Font("Segoe UI", Font.PLAIN, 14);

    public static final Font BUTTON_FONT =
            new Font("Segoe UI", Font.BOLD, 14);


    // ==============================
    // CÀI ĐẶT FRAME
    // ==============================

    public static void setupFrame(JFrame frame, String title) {

        frame.setTitle(title);

        frame.setSize(650, 500);

        frame.setLocationRelativeTo(null);

        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        frame.getContentPane().setBackground(BACKGROUND);

        frame.setResizable(false);
    }


    // ==============================
    // TITLE
    // ==============================

    public static JLabel createTitle(String text) {

        JLabel label = new JLabel(text);

        label.setFont(TITLE_FONT);

        label.setForeground(PINK_HOVER);

        label.setHorizontalAlignment(SwingConstants.CENTER);

        return label;
    }


    // ==============================
    // SUBTITLE
    // ==============================

    public static JLabel createSubtitle(String text) {

        JLabel label = new JLabel(text);

        label.setFont(SUBTITLE_FONT);

        label.setForeground(TEXT_LIGHT);

        label.setHorizontalAlignment(SwingConstants.CENTER);

        return label;
    }


    // ==============================
    // LABEL
    // ==============================

    public static JLabel createLabel(String text) {

        JLabel label = new JLabel(text);

        label.setFont(LABEL_FONT);

        label.setForeground(TEXT);

        return label;
    }


    // ==============================
    // TEXT FIELD
    // ==============================

    public static JTextField createTextField() {

        JTextField field = new JTextField();

        field.setFont(NORMAL_FONT);

        field.setForeground(TEXT);

        field.setBackground(WHITE);

        field.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(
                                BORDER,
                                1
                        ),
                        new EmptyBorder(
                                8,
                                12,
                                8,
                                12
                        )
                )
        );

        return field;
    }


    // ==============================
    // BUTTON
    // ==============================

    public static JButton createButton(String text) {

        JButton button = new JButton(text);

        button.setFont(BUTTON_FONT);

        button.setForeground(Color.WHITE);

        button.setBackground(PINK);

        button.setFocusPainted(false);

        button.setBorderPainted(false);

        button.setOpaque(true);

        button.setCursor(
                new Cursor(Cursor.HAND_CURSOR)
        );

        button.setBorder(
                new EmptyBorder(
                        11,
                        25,
                        11,
                        25
                )
        );

        // Hiệu ứng hover
        button.addMouseListener(new MouseAdapter() {

            @Override
            public void mouseEntered(MouseEvent e) {

                button.setBackground(PINK_HOVER);

                button.setBorder(
                        new EmptyBorder(
                                10,
                                27,
                                12,
                                23
                        )
                );

                button.setForeground(Color.WHITE);
            }

            @Override
            public void mouseExited(MouseEvent e) {

                button.setBackground(PINK);

                button.setBorder(
                        new EmptyBorder(
                                11,
                                25,
                                11,
                                25
                        )
                );
            }

            @Override
            public void mousePressed(MouseEvent e) {

                button.setBackground(
                        new Color(218, 91, 136)
                );

                button.setBorder(
                        new EmptyBorder(
                                12,
                                25,
                                10,
                                25
                        )
                );
            }

            @Override
            public void mouseReleased(MouseEvent e) {

                if (button.contains(e.getPoint())) {

                    button.setBackground(PINK_HOVER);

                } else {

                    button.setBackground(PINK);
                }
            }
        });

        return button;
    }


    // ==============================
    // BUTTON DANGER
    // ==============================

    public static JButton createDangerButton(String text) {

        JButton button = new JButton(text);

        button.setFont(BUTTON_FONT);

        button.setForeground(Color.WHITE);

        button.setBackground(DANGER);

        button.setFocusPainted(false);

        button.setBorderPainted(false);

        button.setOpaque(true);

        button.setCursor(
                new Cursor(Cursor.HAND_CURSOR)
        );

        button.setBorder(
                new EmptyBorder(
                        11,
                        25,
                        11,
                        25
                )
        );

        button.addMouseListener(new MouseAdapter() {

            @Override
            public void mouseEntered(MouseEvent e) {

                button.setBackground(
                        new Color(220, 82, 82)
                );
            }

            @Override
            public void mouseExited(MouseEvent e) {

                button.setBackground(DANGER);
            }

            @Override
            public void mousePressed(MouseEvent e) {

                button.setBackground(
                        new Color(190, 60, 60)
                );
            }

            @Override
            public void mouseReleased(MouseEvent e) {

                button.setBackground(
                        new Color(220, 82, 82)
                );
            }
        });

        return button;
    }


    // ==============================
    // PROGRESS BAR
    // ==============================

    public static void styleProgressBar(
            JProgressBar progressBar
    ) {

        progressBar.setStringPainted(true);

        progressBar.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        12
                )
        );

        progressBar.setForeground(PINK);

        progressBar.setBackground(PINK_LIGHT);

        progressBar.setBorderPainted(false);
    }


    // ==============================
    // CARD
    // ==============================

    public static JPanel createCard() {

        JPanel panel = new JPanel();

        panel.setBackground(WHITE);

        panel.setBorder(
                BorderFactory.createCompoundBorder(

                        BorderFactory.createLineBorder(
                                BORDER,
                                1
                        ),

                        new EmptyBorder(
                                25,
                                30,
                                25,
                                30
                        )
                )
        );

        return panel;
    }


    // ==============================
    // KẾT QUẢ
    // ==============================

    public static JLabel createResultLabel() {

        JLabel label = new JLabel(
                "Kết quả sẽ hiển thị tại đây"
        );

        label.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        15
                )
        );

        label.setForeground(PINK_HOVER);

        label.setHorizontalAlignment(
                SwingConstants.CENTER
        );

        return label;
    }
}