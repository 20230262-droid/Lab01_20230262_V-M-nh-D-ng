package vn.edu.eaut.lab4;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.BufferedReader;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;

public class Bai08_StudentCsvFrame extends JFrame {

    private JButton btnChoose;
    private JButton btnRead;

    private JLabel lblFile;
    private JLabel lblAverage;
    private JLabel lblHighest;

    private JProgressBar progressBar;

    private JTable table;

    private File selectedFile;

    private final Color PURPLE_DARK =
            new Color(46, 16, 73);

    private final Color PURPLE =
            new Color(88, 28, 135);

    private final Color TEAL =
            new Color(13, 148, 136);

    private final Color BG =
            new Color(245, 243, 249);

    public Bai08_StudentCsvFrame() {

        setTitle(
                "Bài 8 - CSV Sinh viên"
        );

        setSize(850, 600);

        setLocationRelativeTo(null);

        setDefaultCloseOperation(
                JFrame.DISPOSE_ON_CLOSE
        );

        initUI();
    }

    private void initUI() {

        JPanel main =
                new JPanel(
                        new BorderLayout()
                );

        main.setBackground(BG);

        JPanel header =
                new JPanel(
                        new BorderLayout()
                );

        header.setBackground(PURPLE_DARK);

        header.setBorder(
                new EmptyBorder(
                        22, 30, 22, 30
                )
        );

        JLabel title =
                new JLabel(
                        "BÀI 8  •  STUDENT CSV"
                );

        title.setForeground(Color.WHITE);

        title.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        23
                )
        );

        JLabel tag =
                new JLabel(
                        "JTABLE + SWINGWORKER"
                );

        tag.setForeground(
                new Color(153, 246, 228)
        );

        tag.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        12
                )
        );

        header.add(
                title,
                BorderLayout.WEST
        );

        header.add(
                tag,
                BorderLayout.EAST
        );

        // TOP

        JPanel top =
                new JPanel(
                        new BorderLayout()
                );

        top.setOpaque(false);

        top.setBorder(
                new EmptyBorder(
                        15, 25, 10, 25
                )
        );

        JPanel buttons =
                new JPanel(
                        new FlowLayout(
                                FlowLayout.LEFT
                        )
                );

        buttons.setOpaque(false);

        btnChoose =
                new JButton(
                        "CHỌN CSV"
                );

        btnRead =
                new JButton(
                        "ĐỌC CSV"
                );

        styleButton(
                btnChoose,
                PURPLE
        );

        styleButton(
                btnRead,
                TEAL
        );

        buttons.add(btnChoose);

        buttons.add(btnRead);

        lblFile =
                new JLabel(
                        "Chưa chọn file"
                );

        lblFile.setForeground(
                new Color(107, 100, 115)
        );

        top.add(
                buttons,
                BorderLayout.WEST
        );

        top.add(
                lblFile,
                BorderLayout.SOUTH
        );

        // TABLE

        table =
                new JTable();

        table.setModel(
                new DefaultTableModel(
                        new Object[]{
                                "Mã SV",
                                "Họ tên",
                                "Điểm"
                        },
                        0
                )
        );

        table.setRowHeight(30);

        table.setFont(
                new Font(
                        "Segoe UI",
                        Font.PLAIN,
                        14
                )
        );

        table.getTableHeader()
                .setFont(
                        new Font(
                                "Segoe UI",
                                Font.BOLD,
                                14
                        )
                );

        JScrollPane scroll =
                new JScrollPane(table);

        // BOTTOM

        JPanel bottom =
                new JPanel();

        bottom.setLayout(
                new BoxLayout(
                        bottom,
                        BoxLayout.Y_AXIS
                )
        );

        bottom.setBorder(
                new EmptyBorder(
                        10, 25, 20, 25
                )
        );

        bottom.setOpaque(false);

        lblAverage =
                new JLabel(
                        "Điểm trung bình: --"
                );

        lblHighest =
                new JLabel(
                        "Sinh viên cao nhất: --"
                );

        lblAverage.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        15
                )
        );

        lblHighest.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        15
                )
        );

        progressBar =
                new JProgressBar(
                        0,
                        100
                );

        progressBar.setStringPainted(true);

        progressBar.setForeground(TEAL);

        bottom.add(lblAverage);

        bottom.add(
                Box.createVerticalStrut(5)
        );

        bottom.add(lblHighest);

        bottom.add(
                Box.createVerticalStrut(10)
        );

        bottom.add(progressBar);

        main.add(
                header,
                BorderLayout.NORTH
        );

        main.add(
                top,
                BorderLayout.BEFORE_FIRST_LINE
        );

        main.add(
                scroll,
                BorderLayout.CENTER
        );

        main.add(
                bottom,
                BorderLayout.SOUTH
        );

        add(main);

        btnChoose.addActionListener(
                e -> chooseFile()
        );

        btnRead.addActionListener(
                e -> readCsv()
        );
    }

    private void styleButton(
            JButton button,
            Color color
    ) {

        button.setForeground(Color.WHITE);

        button.setBackground(color);

        button.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        13
                )
        );

        button.setFocusPainted(false);

        button.setBorderPainted(false);
    }

    private void chooseFile() {

        JFileChooser chooser =
                new JFileChooser();

        int result =
                chooser.showOpenDialog(this);

        if (
                result ==
                        JFileChooser.APPROVE_OPTION
        ) {

            selectedFile =
                    chooser.getSelectedFile();

            lblFile.setText(
                    selectedFile
                            .getAbsolutePath()
            );
        }
    }

    private void readCsv() {

        if (selectedFile == null) {

            JOptionPane.showMessageDialog(
                    this,
                    "Vui lòng chọn file CSV",
                    "Thông báo",
                    JOptionPane.WARNING_MESSAGE
            );

            return;
        }

        btnRead.setEnabled(false);

        DefaultTableModel model =
                (DefaultTableModel)
                        table.getModel();

        model.setRowCount(0);

        progressBar.setValue(0);

        SwingWorker<List<Student>, Void> worker =
                new SwingWorker<>() {

                    @Override
                    protected List<Student>
                    doInBackground()
                            throws Exception {

                        List<Student> students =
                                new ArrayList<>();

                        List<String> lines =
                                Files.readAllLines(
                                        selectedFile.toPath(),
                                        StandardCharsets.UTF_8
                                );

                        int total =
                                lines.size();

                        for (
                                int i = 1;
                                i < lines.size();
                                i++
                        ) {

                            String line =
                                    lines.get(i);

                            String[] parts =
                                    line.split(",");

                            if (parts.length >= 3) {

                                String id =
                                        parts[0].trim();

                                String name =
                                        parts[1].trim();

                                double score =
                                        Double.parseDouble(
                                                parts[2].trim()
                                        );

                                students.add(
                                        new Student(
                                                id,
                                                name,
                                                score
                                        )
                                );
                            }

                            setProgress(
                                    (i * 100)
                                            / Math.max(
                                            total,
                                            1
                                    )
                            );

                            Thread.sleep(20);
                        }

                        return students;
                    }

                    @Override
                    protected void done() {

                        try {

                            List<Student> students =
                                    get();

                            double total = 0;

                            Student highest = null;

                            DefaultTableModel model =
                                    (DefaultTableModel)
                                            table.getModel();

                            for (
                                    Student s :
                                    students
                            ) {

                                model.addRow(
                                        new Object[]{
                                                s.id,
                                                s.name,
                                                s.score
                                        }
                                );

                                total += s.score;

                                if (
                                        highest == null
                                                || s.score
                                                > highest.score
                                ) {

                                    highest = s;
                                }
                            }

                            double average =
                                    students.isEmpty()
                                            ? 0
                                            : total
                                            / students.size();

                            lblAverage.setText(
                                    String.format(
                                            "Điểm trung bình: %.2f",
                                            average
                                    )
                            );

                            if (highest != null) {

                                lblHighest.setText(
                                        "Sinh viên cao nhất: "
                                                + highest.name
                                                + " - "
                                                + highest.score
                                );
                            }

                        } catch (Exception ex) {

                            JOptionPane.showMessageDialog(
                                    Bai08_StudentCsvFrame.this,
                                    "Lỗi khi đọc CSV",
                                    "Lỗi",
                                    JOptionPane.ERROR_MESSAGE
                            );
                        }

                        progressBar.setValue(100);

                        btnRead.setEnabled(true);
                    }
                };

        worker.addPropertyChangeListener(
                evt -> {

                    if (
                            "progress".equals(
                                    evt.getPropertyName()
                            )
                    ) {

                        progressBar.setValue(
                                (int) evt.getNewValue()
                        );
                    }
                }
        );

        worker.execute();
    }

    private static class Student {

        String id;
        String name;
        double score;

        Student(
                String id,
                String name,
                double score
        ) {

            this.id = id;
            this.name = name;
            this.score = score;
        }
    }
}