package vn.edu.eaut.lab4;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;

public class Bai10_ProductManagerFrame extends JFrame {

    private JTextField txtId;
    private JTextField txtName;
    private JTextField txtPrice;

    private JButton btnAdd;
    private JButton btnUpdate;
    private JButton btnDelete;
    private JButton btnSave;
    private JButton btnLoad;

    private JTable table;

    private JProgressBar progressBar;

    private JLabel lblStatus;

    private File csvFile;

    private final Color PURPLE_DARK =
            new Color(46, 16, 73);

    private final Color PURPLE =
            new Color(88, 28, 135);

    private final Color TEAL =
            new Color(13, 148, 136);

    private final Color RED =
            new Color(220, 38, 38);

    private final Color BG =
            new Color(245, 243, 249);

    public Bai10_ProductManagerFrame() {

        setTitle(
                "Bài 10 - Quản lý sản phẩm CSV"
        );

        setSize(950, 650);

        setLocationRelativeTo(null);

        setDefaultCloseOperation(
                JFrame.DISPOSE_ON_CLOSE
        );

        initUI();
    }

    private void initUI() {

        JPanel main =
                new JPanel(
                        new BorderLayout()
                );

        main.setBackground(BG);

        // HEADER

        JPanel header =
                new JPanel(
                        new BorderLayout()
                );

        header.setBackground(PURPLE_DARK);

        header.setBorder(
                new EmptyBorder(
                        22, 30, 22, 30
                )
        );

        JLabel title =
                new JLabel(
                        "BÀI 10  •  PRODUCT MANAGER"
                );

        title.setForeground(Color.WHITE);

        title.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        24
                )
        );

        JLabel tag =
                new JLabel(
                        "CSV + SWINGWORKER"
                );

        tag.setForeground(
                new Color(153, 246, 228)
        );

        tag.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        12
                )
        );

        header.add(
                title,
                BorderLayout.WEST
        );

        header.add(
                tag,
                BorderLayout.EAST
        );

        // INPUT PANEL

        JPanel input =
                new JPanel(
                        new GridBagLayout()
                );

        input.setOpaque(false);

        input.setBorder(
                new EmptyBorder(
                        20, 30, 10, 30
                )
        );

        GridBagConstraints gbc =
                new GridBagConstraints();

        gbc.insets =
                new Insets(
                        5, 8, 5, 8
                );

        gbc.fill =
                GridBagConstraints.HORIZONTAL;

        JLabel lblId =
                new JLabel("Mã SP:");

        JLabel lblName =
                new JLabel("Tên SP:");

        JLabel lblPrice =
                new JLabel("Đơn giá:");

        txtId =
                new JTextField();

        txtName =
                new JTextField();

        txtPrice =
                new JTextField();

        txtId.setPreferredSize(
                new Dimension(150, 35)
        );

        txtName.setPreferredSize(
                new Dimension(220, 35)
        );

        txtPrice.setPreferredSize(
                new Dimension(160, 35)
        );

        gbc.gridx = 0;
        gbc.gridy = 0;

        input.add(
                lblId,
                gbc
        );

        gbc.gridx = 1;

        input.add(
                txtId,
                gbc
        );

        gbc.gridx = 2;

        input.add(
                lblName,
                gbc
        );

        gbc.gridx = 3;

        input.add(
                txtName,
                gbc
        );

        gbc.gridx = 0;
        gbc.gridy = 1;

        input.add(
                lblPrice,
                gbc
        );

        gbc.gridx = 1;

        input.add(
                txtPrice,
                gbc
        );

        // BUTTONS

        JPanel buttons =
                new JPanel(
                        new FlowLayout(
                                FlowLayout.CENTER,
                                8,
                                5
                        )
                );

        buttons.setOpaque(false);

        btnAdd =
                new JButton("THÊM");

        btnUpdate =
                new JButton("SỬA");

        btnDelete =
                new JButton("XÓA");

        btnSave =
                new JButton("LƯU CSV");

        btnLoad =
                new JButton("ĐỌC CSV");

        styleButton(
                btnAdd,
                TEAL
        );

        styleButton(
                btnUpdate,
                PURPLE
        );

        styleButton(
                btnDelete,
                RED
        );

        styleButton(
                btnSave,
                PURPLE
        );

        styleButton(
                btnLoad,
                TEAL
        );

        buttons.add(btnAdd);
        buttons.add(btnUpdate);
        buttons.add(btnDelete);
        buttons.add(btnSave);
        buttons.add(btnLoad);

        gbc.gridx = 2;
        gbc.gridy = 1;

        gbc.gridwidth = 2;

        input.add(
                buttons,
                gbc
        );

        // TABLE

        table =
                new JTable();

        table.setModel(
                new DefaultTableModel(
                        new Object[]{
                                "Mã SP",
                                "Tên sản phẩm",
                                "Đơn giá"
                        },
                        0
                )
        );

        table.setRowHeight(32);

        table.setFont(
                new Font(
                        "Segoe UI",
                        Font.PLAIN,
                        14
                )
        );

        table.getTableHeader()
                .setFont(
                        new Font(
                                "Segoe UI",
                                Font.BOLD,
                                14
                        )
                );

        JScrollPane scroll =
                new JScrollPane(table);

        // BOTTOM

        JPanel bottom =
                new JPanel();

        bottom.setLayout(
                new BoxLayout(
                        bottom,
                        BoxLayout.Y_AXIS
                )
        );

        bottom.setBorder(
                new EmptyBorder(
                        10, 30, 20, 30
                )
        );

        bottom.setOpaque(false);

        lblStatus =
                new JLabel(
                        "Sẵn sàng"
                );

        lblStatus.setAlignmentX(
                Component.CENTER_ALIGNMENT
        );

        lblStatus.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        14
                )
        );

        progressBar =
                new JProgressBar(
                        0,
                        100
                );

        progressBar.setStringPainted(true);

        progressBar.setForeground(TEAL);

        bottom.add(lblStatus);

        bottom.add(
                Box.createVerticalStrut(8)
        );

        bottom.add(progressBar);

        main.add(
                header,
                BorderLayout.NORTH
        );

        main.add(
                input,
                BorderLayout.BEFORE_FIRST_LINE
        );

        main.add(
                scroll,
                BorderLayout.CENTER
        );

        main.add(
                bottom,
                BorderLayout.SOUTH
        );

        add(main);

        // EVENTS

        btnAdd.addActionListener(
                e -> addProduct()
        );

        btnUpdate.addActionListener(
                e -> updateProduct()
        );

        btnDelete.addActionListener(
                e -> deleteProduct()
        );

        btnSave.addActionListener(
                e -> saveCsv()
        );

        btnLoad.addActionListener(
                e -> loadCsv()
        );

        table.getSelectionModel()
                .addListSelectionListener(
                        e -> fillForm()
                );
    }

    private void styleButton(
            JButton button,
            Color color
    ) {

        button.setForeground(Color.WHITE);

        button.setBackground(color);

        button.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        12
                )
        );

        button.setFocusPainted(false);

        button.setBorderPainted(false);
    }

    private void addProduct() {

        String id =
                txtId.getText().trim();

        String name =
                txtName.getText().trim();

        String priceText =
                txtPrice.getText().trim();

        if (
                id.isEmpty()
                        || name.isEmpty()
                        || priceText.isEmpty()
        ) {

            JOptionPane.showMessageDialog(
                    this,
                    "Vui lòng nhập đầy đủ thông tin",
                    "Thông báo",
                    JOptionPane.WARNING_MESSAGE
            );

            return;
        }

        double price;

        try {

            price =
                    Double.parseDouble(
                            priceText
                    );

        } catch (NumberFormatException ex) {

            JOptionPane.showMessageDialog(
                    this,
                    "Đơn giá không hợp lệ",
                    "Lỗi",
                    JOptionPane.ERROR_MESSAGE
            );

            return;
        }

        DefaultTableModel model =
                (DefaultTableModel)
                        table.getModel();

        model.addRow(
                new Object[]{
                        id,
                        name,
                        price
                }
        );

        clearForm();

        lblStatus.setText(
                "✓ Đã thêm sản phẩm"
        );
    }

    private void updateProduct() {

        int row =
                table.getSelectedRow();

        if (row == -1) {

            JOptionPane.showMessageDialog(
                    this,
                    "Vui lòng chọn sản phẩm cần sửa",
                    "Thông báo",
                    JOptionPane.WARNING_MESSAGE
            );

            return;
        }

        String id =
                txtId.getText().trim();

        String name =
                txtName.getText().trim();

        double price;

        try {

            price =
                    Double.parseDouble(
                            txtPrice
                                    .getText()
                                    .trim()
                    );

        } catch (NumberFormatException ex) {

            JOptionPane.showMessageDialog(
                    this,
                    "Đơn giá không hợp lệ",
                    "Lỗi",
                    JOptionPane.ERROR_MESSAGE
            );

            return;
        }

        DefaultTableModel model =
                (DefaultTableModel)
                        table.getModel();

        model.setValueAt(
                id,
                row,
                0
        );

        model.setValueAt(
                name,
                row,
                1
        );

        model.setValueAt(
                price,
                row,
                2
        );

        lblStatus.setText(
                "✓ Đã cập nhật sản phẩm"
        );
    }

    private void deleteProduct() {

        int row =
                table.getSelectedRow();

        if (row == -1) {

            JOptionPane.showMessageDialog(
                    this,
                    "Vui lòng chọn sản phẩm cần xóa",
                    "Thông báo",
                    JOptionPane.WARNING_MESSAGE
            );

            return;
        }

        DefaultTableModel model =
                (DefaultTableModel)
                        table.getModel();

        model.removeRow(row);

        clearForm();

        lblStatus.setText(
                "✓ Đã xóa sản phẩm"
        );
    }

    private void fillForm() {

        int row =
                table.getSelectedRow();

        if (row == -1) {
            return;
        }

        txtId.setText(
                table.getValueAt(
                        row,
                        0
                ).toString()
        );

        txtName.setText(
                table.getValueAt(
                        row,
                        1
                ).toString()
        );

        txtPrice.setText(
                table.getValueAt(
                        row,
                        2
                ).toString()
        );
    }

    private void clearForm() {

        txtId.setText("");

        txtName.setText("");

        txtPrice.setText("");
    }

    private void saveCsv() {

        JFileChooser chooser =
                new JFileChooser();

        int result =
                chooser.showSaveDialog(this);

        if (
                result !=
                        JFileChooser.APPROVE_OPTION
        ) {
            return;
        }

        csvFile =
                chooser.getSelectedFile();

        btnSave.setEnabled(false);

        progressBar.setValue(0);

        lblStatus.setText(
                "Đang lưu CSV..."
        );

        SwingWorker<Void, Void> worker =
                new SwingWorker<>() {

                    @Override
                    protected Void doInBackground()
                            throws Exception {

                        DefaultTableModel model =
                                (DefaultTableModel)
                                        table.getModel();

                        int rows =
                                model.getRowCount();

                        try (
                                BufferedWriter writer =
                                        Files.newBufferedWriter(
                                                csvFile.toPath(),
                                                StandardCharsets.UTF_8
                                        )
                        ) {

                            writer.write(
                                    "MaSP,TenSP,DonGia"
                            );

                            writer.newLine();

                            for (
                                    int i = 0;
                                    i < rows;
                                    i++
                            ) {

                                String id =
                                        model.getValueAt(
                                                i,
                                                0
                                        ).toString();

                                String name =
                                        model.getValueAt(
                                                i,
                                                1
                                        ).toString();

                                String price =
                                        model.getValueAt(
                                                i,
                                                2
                                        ).toString();

                                writer.write(
                                        id
                                                + ","
                                                + name
                                                + ","
                                                + price
                                );

                                writer.newLine();

                                setProgress(
                                        (i + 1)
                                                * 100
                                                / Math.max(
                                                rows,
                                                1
                                        )
                                );
                            }
                        }

                        return null;
                    }

                    @Override
                    protected void done() {

                        progressBar.setValue(
                                100
                        );

                        btnSave.setEnabled(true);

                        lblStatus.setText(
                                "✓ Đã lưu CSV thành công"
                        );
                    }
                };

        worker.addPropertyChangeListener(
                evt -> {

                    if (
                            "progress".equals(
                                    evt.getPropertyName()
                            )
                    ) {

                        progressBar.setValue(
                                (int) evt.getNewValue()
                        );
                    }
                }
        );

        worker.execute();
    }

    private void loadCsv() {

        JFileChooser chooser =
                new JFileChooser();

        int result =
                chooser.showOpenDialog(this);

        if (
                result !=
                        JFileChooser.APPROVE_OPTION
        ) {
            return;
        }

        csvFile =
                chooser.getSelectedFile();

        btnLoad.setEnabled(false);

        progressBar.setValue(0);

        lblStatus.setText(
                "Đang đọc CSV..."
        );

        SwingWorker<List<Product>, Void> worker =
                new SwingWorker<>() {

                    @Override
                    protected List<Product>
                    doInBackground()
                            throws Exception {

                        List<Product> products =
                                new ArrayList<>();

                        List<String> lines =
                                Files.readAllLines(
                                        csvFile.toPath(),
                                        StandardCharsets.UTF_8
                                );

                        int total =
                                lines.size();

                        for (
                                int i = 1;
                                i < lines.size();
                                i++
                        ) {

                            String[] parts =
                                    lines.get(i)
                                            .split(",");

                            if (parts.length >= 3) {

                                products.add(
                                        new Product(
                                                parts[0].trim(),
                                                parts[1].trim(),
                                                Double.parseDouble(
                                                        parts[2]
                                                                .trim()
                                                )
                                        )
                                );
                            }

                            setProgress(
                                    i * 100
                                            / Math.max(
                                            total,
                                            1
                                    )
                            );

                            Thread.sleep(30);
                        }

                        return products;
                    }

                    @Override
                    protected void done() {

                        try {

                            List<Product> products =
                                    get();

                            DefaultTableModel model =
                                    (DefaultTableModel)
                                            table.getModel();

                            model.setRowCount(0);

                            for (
                                    Product p :
                                    products
                            ) {

                                model.addRow(
                                        new Object[]{
                                                p.id,
                                                p.name,
                                                p.price
                                        }
                                );
                            }

                            lblStatus.setText(
                                    "✓ Đã đọc "
                                            + products.size()
                                            + " sản phẩm"
                            );

                        } catch (Exception ex) {

                            lblStatus.setText(
                                    "Lỗi khi đọc CSV"
                            );
                        }

                        progressBar.setValue(
                                100
                        );

                        btnLoad.setEnabled(true);
                    }
                };

        worker.addPropertyChangeListener(
                evt -> {

                    if (
                            "progress".equals(
                                    evt.getPropertyName()
                            )
                    ) {

                        progressBar.setValue(
                                (int) evt.getNewValue()
                        );
                    }
                }
        );

        worker.execute();
    }

    private static class Product {

        String id;
        String name;
        double price;

        Product(
                String id,
                String name,
                double price
        ) {

            this.id = id;

            this.name = name;

            this.price = price;
        }
    }
}